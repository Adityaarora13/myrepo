package com.example.EmployeeManagement.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class EmployeeDTO {
    private Long id;
    private String name;
    private String department;
    private LocalDate joiningDate;
    private String email;
    private String phone;
    private String reportingManager;
}