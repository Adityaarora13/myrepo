package com.example.Api_gateway.Filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class gatewayconfig {
    @Autowired
    private JwtAuthenticationFilter jwtAuthFilter;
    @Bean
    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("admin-service", r -> r.path("/api/admin/**")
                        .filters(f -> f.filter(jwtAuthFilter))
                        .uri("lb://ADMINSERVICE"))
                .route("dealer-service", r -> r.path("/api/dealer/**")
                        .filters(f -> f.filter(jwtAuthFilter))
                        .uri("lb://DEALERSERVICE"))
                .route("farmer-service", r -> r.path("/api/farmer/**")
                        .filters(f -> f.filter(jwtAuthFilter))
                        .uri("lb://FARMERSERVICE"))
                .route("auth-service", r -> r.path("/api/auth/**")
                        .uri("lb://AUTHSERVICE"))
                .route("farmer-service", r -> r.path("/api/crops/**")
                        .filters(f -> f.filter(jwtAuthFilter))
                        .uri("lb://FARMERSERVICE"))
                .build();
    }

}


