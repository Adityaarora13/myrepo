package com.example.Api_gateway.Filter;

import com.example.Api_gateway.Exceptions.AccessDenied;
import com.example.Api_gateway.Exceptions.InvalidToken;
import com.example.Api_gateway.Exceptions.MissingToken;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.InvalidClaimException;
import io.jsonwebtoken.Jwts;
import jakarta.ws.rs.core.HttpHeaders;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.channels.AcceptPendingException;

// order-> for execution of filters according to the value of getOrder method
// Gateway Filter->
// This makes JwtAuthenticationFilter run before most other filters — ensuring
//        unauthorized requests are blocked ASAP, saving resources and improving security.
@Component
public class JwtAuthenticationFilter implements GatewayFilter, Ordered {
    private final String SECRET_KEY = "2345678weewewe9ioiuytrdfghjikjhgytr56tyuijhgfxd"; // use the same one as Auth Service
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String path = exchange.getRequest().getURI().getPath();
        String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new MissingToken("Token is missing in the header ");

        }
        String token = authHeader.substring(7);
        try {
            Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
            String role = claims.get("role", String.class);
            // Role-based access control
            if (path.startsWith("/api/admin") && !role.equals("ADMIN")) {
                throw new AccessDenied("You can not access to this route with this token. Use token with Admin role to access it");

            }
            if (path.startsWith("/api/dealer") && !role.equals("DEALER")) {
                throw new AccessDenied("You can not access to this route with this token. Use token with Dealer role to access it");

            }
            if (path.startsWith("/api/farmer") && !role.equals("FARMER")) {
                throw new AccessDenied("You can not access to this route with this token. Use token with Farmer role to access it");

            }
            if (path.startsWith("/api/crops") && !role.equals("FARMER")) {
                throw new AccessDenied("You can not access to this route with this token. Use token with Farmer role to access it");

            }
        }
        catch (AccessDenied ex){
           throw new AccessDenied(ex.getMessage());
        }
        catch (Exception e) {

            throw new InvalidToken("Token Is Invalid Please Insert correct Token");
        }
        return chain.filter(exchange);
//        If no exception is thrown, the request continues.
    }

//    This method sets the HTTP status code and completes the
//    response without returning any data, hence the Mono<Void>.
    private Mono<Void> onError(ServerWebExchange exchange, String message, HttpStatus status) {
        exchange.getResponse().setStatusCode(status);
        return exchange.getResponse().setComplete();
    }


//    This makes JwtAuthenticationFilter run before most other filters —
//    ensuring unauthorized requests are blocked ASAP, saving resources and improving security.

    @Override
    public int getOrder() {
        return -1; // Run this filter before others
    }
}

