package com.example.Api_gateway.Exceptions;

public class MissingToken extends  RuntimeException{
    public MissingToken(String message){
        super(message);
    }
}
