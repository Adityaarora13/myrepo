package com.payment.PaymentGateway.controller;
import com.payment.PaymentGateway.DTO.PaymentInfo;
import com.payment.PaymentGateway.repository.PaymentInfoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class PaymentStatusController {

    private final PaymentInfoRepository paymentInfoRepository;

    @PostMapping("/save-payment")
    public String savePaymentDetails(
            @RequestParam String paymentId,
            @RequestParam String orderId,
            @RequestParam String status,
            @RequestParam double amount,
            @RequestParam String currency,
            @RequestParam Long dealerId
    ) {
        PaymentInfo payment = new PaymentInfo();
        payment.setDealerId(dealerId);
        payment.setAmount(amount);
        payment.setCurrency(currency);
        payment.setStatus(status);
        payment.setPaymentId(paymentId);
        payment.setOrderId(orderId);
        payment.setPaymentTime(LocalDateTime.now());

        paymentInfoRepository.save(payment);

        return "Payment information saved successfully!";
    }
}

