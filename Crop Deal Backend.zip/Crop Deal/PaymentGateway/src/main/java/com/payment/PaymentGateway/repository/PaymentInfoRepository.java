package com.payment.PaymentGateway.repository;

import com.payment.PaymentGateway.DTO.PaymentInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentInfoRepository extends JpaRepository<PaymentInfo, Long> {
}
