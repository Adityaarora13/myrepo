package com.payment.PaymentGateway.DTO;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
public class PaymentInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long dealerId;
    private double amount;
    private String currency;
    private String status;
    private String paymentId;
    private String orderId;

    private LocalDateTime paymentTime;
}
