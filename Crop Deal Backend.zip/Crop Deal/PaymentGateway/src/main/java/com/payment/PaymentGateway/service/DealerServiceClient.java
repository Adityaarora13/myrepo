package com.payment.PaymentGateway.service;


import com.payment.PaymentGateway.DTO.CartItems;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;


@FeignClient(name = "DEALERSERVICE", url = "http://localhost:8083")
public interface DealerServiceClient {
    @GetMapping("/api/dealer/price/{dealerId}")
    double calculateTotalAmountInCart(@PathVariable Long dealerId);


    @GetMapping("/api/dealer/cart/{dealerId}")
     List<CartItems> getCartByDealerId(@PathVariable Long dealerId);

}


