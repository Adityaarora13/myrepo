package com.payment.PaymentGateway.controller;

import com.payment.PaymentGateway.DTO.CartItems;
import com.payment.PaymentGateway.service.DealerServiceClient;
import com.payment.PaymentGateway.service.RazorPayService;
import com.razorpay.RazorpayException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(
        origins = "http://localhost:4200",
        methods = {RequestMethod.GET, RequestMethod.POST,
                RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS},
        allowedHeaders = "*",
        allowCredentials = "true"   // only if you really need cookies/Authorization
)
@RequiredArgsConstructor
public class PaymentController {

    private final RazorPayService razorPayService;
    private final DealerServiceClient dealerServiceClient;

    /**
     * Get cart details and total amount for a specific dealer
     */
    @GetMapping("/cart-details/{dealerId}")
    public ResponseEntity<Map<String, Object>> getCartDetails(@PathVariable Long dealerId) {
        List<CartItems> cartItems = dealerServiceClient.getCartByDealerId(dealerId);
        double totalAmount = dealerServiceClient.calculateTotalAmountInCart(dealerId);

        Map<String, Object> response = new HashMap<>();
        response.put("cartItems", cartItems);
        response.put("totalAmount", totalAmount);

        return ResponseEntity.ok(response);
    }

    /**
     * Create a Razorpay order based on dealer's cart total
     */
//    @PostMapping("/create-order")
//    public ResponseEntity<String> createOrder(
//            @RequestParam Long dealerId,
//            @RequestParam String currency) {
//
//        double amount = dealerServiceClient.calculateTotalAmountInCart(dealerId);
//
//        try {
//            String order = razorPayService.createOrder((int) amount, currency, "receipt_100");
//            return ResponseEntity.ok(order);
//        } catch (RazorpayException e) {
//            return ResponseEntity.internalServerError().body("Failed to create order: " + e.getMessage());
//        }
 //   }
    @PostMapping("/create-order")
    public ResponseEntity<String> createOrder(
            @RequestParam Long dealerId,
            @RequestParam String currency,
            @RequestParam Integer amount) {  // Add amount parameter
        try {
            String order = razorPayService.createOrder(amount, currency, "receipt_100");
            return ResponseEntity.ok(order);
        } catch (RazorpayException e) {
            return ResponseEntity.internalServerError().body("Failed to create order: " + e.getMessage());
        }
    }

}

