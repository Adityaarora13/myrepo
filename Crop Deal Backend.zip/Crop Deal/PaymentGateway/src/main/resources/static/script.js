document.getElementById('fetch-cart-button').onclick = function () {
    const dealerId = document.getElementById('dealerId').value;

    fetch(`http://localhost:8084/api/payments/cart-details/${dealerId}`)
        .then(response => response.json())
        .then(data => {
            const cartItems = data.cartItems;
            const totalAmount = data.totalAmount;
            const cartDetailsDiv = document.getElementById('cart-details');
            cartDetailsDiv.innerHTML = ''; // Clear previous

            cartItems.forEach(item => {
                const cartItemDiv = document.createElement('div');
                cartItemDiv.className = 'cart-item';
                cartItemDiv.innerHTML = `
                    <p>Crop Name: ${item.cropName}</p>
                    <p>Crop Type: ${item.cropType}</p>
                    <p>Price per Kg: ${item.pricePerKg}</p>
                    <p>Quantity Available: ${item.quantityAvailable}</p>
                `;
                cartDetailsDiv.appendChild(cartItemDiv);
            });

            const totalAmountDiv = document.createElement('div');
            totalAmountDiv.innerHTML = `<p>Total Amount: ${totalAmount}</p>`;
            cartDetailsDiv.appendChild(totalAmountDiv);

            document.getElementById('pay-button').style.display = 'block';
        })
        .catch(err => {
            console.error('Fetch error:', err);
            alert('Failed to fetch cart details.');
        });
};

document.getElementById('payment-form').onsubmit = function (event) {
    event.preventDefault();

    const dealerId = document.getElementById('dealerId').value;
    const currency = document.getElementById('currency').value;

    fetch(`http://localhost:8084/api/payments/create-order?dealerId=${dealerId}&currency=${currency}`, {
        method: 'POST'
    })
        .then(response => response.text())
        .then(orderString => {
            const order = JSON.parse(orderString);

            const options = {
                key: "rzp_test_bqLZ9en02DpnL9",
                amount: order.amount,
                currency: order.currency,
                name: "Crop Deals",
                description: "Crop Payment",
                order_id: order.id,

                handler: function (response) {
                    alert("Payment Successful! Payment ID: " + response.razorpay_payment_id);

                    // Save and empty cart on success
                    savePayment(response, "SUCCESS", order.amount / 100, currency, dealerId, true);
                },

                modal: {
                    ondismiss: function () {
                        // Save dismissed payment
                        savePayment({
                            razorpay_payment_id: "N/A",
                            razorpay_order_id: order.id
                        }, "DISMISSED", order.amount / 100, currency, dealerId, false);
                    }
                },

                theme: {
                    color: "#3399cc"
                }
            };

            const rzp = new Razorpay(options);

            rzp.on('payment.failed', function (response) {
                savePayment({
                    razorpay_payment_id: response.error.metadata.payment_id || "N/A",
                    razorpay_order_id: response.error.metadata.order_id
                }, "FAILED", order.amount / 100, currency, dealerId, false);
            });

            rzp.open();
        })
        .catch(err => console.error("Error creating order:", err));
};

function savePayment(response, status, amount, currency, dealerId, shouldEmptyCart) {
    fetch('http://localhost:8084/api/payments/save-payment', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            paymentId: response.razorpay_payment_id || "N/A",
            orderId: response.razorpay_order_id || "N/A",
            status: status,
            amount: amount,
            currency: currency,
            dealerId: dealerId
        })
    })
        .then(res => res.text())
        .then(data => {
            console.log("Payment saved:", data);

            if (shouldEmptyCart) {
                // Clear cart on successful payment
                fetch(`http://localhost:8083/api/dealer/cart/empty/${dealerId}`, {
                    method: 'DELETE'
                })
                    .then(() => {
                        alert("Cart emptied successfully after payment.");
                        console.log("Dealer cart cleared.");
                    })
                    .catch(err => {
                        console.error("Error emptying cart:", err);
                        alert("Payment saved but failed to empty cart.");
                    });
            }
        })
        .catch(err => {
            console.error('Error saving payment:', err);
        });
}
