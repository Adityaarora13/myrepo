package com.payment.PaymentGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
