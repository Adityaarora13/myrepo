package com.dealer.Dealer_service.Service;

import com.dealer.Dealer_service.DTO.CropDTO;
import com.dealer.Dealer_service.Model.CartItem;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "FARMERSERVICE")
public interface FarmerClient {


    @GetMapping("/api/FarmerCrop/allcrops")
    public List<CropDTO> getallcrops();

    @GetMapping("/api/FarmerCrop/crop/{cropId}/farmer")
    Object getFarmerDetailsForCrop(@PathVariable Long cropId);

    @GetMapping("/api/crops/{id}")
    CartItem getCropById(@PathVariable Long id);

    @GetMapping("/api/FarmerCrop/farmer/{farmerId}/crop")
    Object getCropDetailsForFarmer(@PathVariable Long farmerId);

    @GetMapping("/api/crops/crop/{cropName}")
    List<CropDTO> getCropsByName(@PathVariable String cropName);
}
