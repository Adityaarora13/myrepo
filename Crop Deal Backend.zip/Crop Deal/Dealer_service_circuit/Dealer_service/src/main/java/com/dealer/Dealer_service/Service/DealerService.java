package com.dealer.Dealer_service.Service;

import com.dealer.Dealer_service.DTO.CropDTO;
import com.dealer.Dealer_service.Model.CartItem;
import com.dealer.Dealer_service.Model.Dealer;
import jakarta.transaction.Transactional;

import java.util.List;

public interface DealerService {

    Dealer createDealer(Dealer dealer);
    Dealer getDealerById(Long dealerId);
    Dealer getDealerByEmail(String emailId);
    List<Dealer> getAllDealers();
    Dealer updateDealer(Long dealerId, Dealer dealer);
    void deleteDealer(Long dealerId);
    double calculateTotalAmountInCart(Long dealerId);


    public List<CropDTO> viewAllCrops();

    Object getCropDetailsForFarmer( Long farmerId);
    Object getFarmerDetailsForCrop( Long cropId);
    List<CropDTO> getCropsByName( String cropName);

    //add the cartitem in the Dealer CartList
    CartItem addItemInCart(Long cropId , Long dealerId);

    boolean deleteItemFromCart(Long cropId, Long dealerId);


    List<CartItem> getAllCartByDealer(Long dealerId);


    @Transactional
    String deleteByEmail(String email);

    Object emptyCartList(Long dealerId);


}
