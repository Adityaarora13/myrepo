package com.dealer.Dealer_service.Repository;

import com.dealer.Dealer_service.Model.CartItem;
import com.dealer.Dealer_service.Model.Dealer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DealerRepository extends JpaRepository<Dealer , Long> {
    void deleteByEmail(String email);

    Optional<Dealer> findByEmail(String emailId);


}
