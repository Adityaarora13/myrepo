package com.dealer.Dealer_service.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "dealers")
public class Dealer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long dealerId;

    private String name;
    private String email;
    private String contactNumber;

//    fetch = FetchType.LAZY
//    Jab tak cart list ki zarurat na ho,
//    tab tak wo DB se load nahi hogi (performance friendly)


//    cascade = CascadeType.ALL
//    Jab dealer save/delete/update hoga,
//    to uske cart items pe bhi effect padega

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "dealer_id")
    private List<CartItem> DealerCart = new ArrayList<>();
}

