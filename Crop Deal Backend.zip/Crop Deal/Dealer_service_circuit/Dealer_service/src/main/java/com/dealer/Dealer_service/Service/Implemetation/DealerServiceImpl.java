package com.dealer.Dealer_service.Service.Implemetation;

import com.dealer.Dealer_service.DTO.CropDTO;
import com.dealer.Dealer_service.ExceptionHandle.DuplicateException;
import com.dealer.Dealer_service.ExceptionHandle.EntryNotFound;
import com.dealer.Dealer_service.Model.CartItem;
import com.dealer.Dealer_service.Model.Dealer;
import com.dealer.Dealer_service.Repository.CartItemRepository;
import com.dealer.Dealer_service.Repository.DealerRepository;
import com.dealer.Dealer_service.Service.DealerService;
import com.dealer.Dealer_service.Service.FarmerClient;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class DealerServiceImpl implements DealerService {

    private static final Logger log = LoggerFactory.getLogger(DealerServiceImpl.class);

    @Autowired
    private final DealerRepository dealerRepository;
    private final FarmerClient farmerClient;
    @Autowired
    private final CartItemRepository cartItemRepository;

    // Create Dealer
    @Override
    public Dealer createDealer(Dealer dealer) {
        log.info("Creating dealer with email: {}", dealer.getEmail());
        return dealerRepository.save(dealer);
    }

    // Find Dealer By Id
    @Override
    public Dealer getDealerById(Long dealerId) {
        log.info("Fetching dealer by ID: {}", dealerId);
        return dealerRepository.findById(dealerId)
                .orElseThrow(() -> new EntryNotFound("Dealer not found with ID: " + dealerId));
    }

    // Find Dealer By Email Id
    @Override
    public Dealer getDealerByEmail(String emailId) {
        log.info("Fetching dealer by email: {}", emailId);
        return dealerRepository.findByEmail(emailId)
                .orElseThrow(() -> new EntryNotFound("Dealer not found with ID: " + emailId));
    }

    // Find All Dealers
    @Override
    public List<Dealer> getAllDealers() {
        log.info("Fetching all dealers");
        List<Dealer> dealers = dealerRepository.findAll();
        if (dealers == null || dealers.isEmpty()) {
            log.warn("No dealers found in the system.");
            throw new EntryNotFound("No dealers found in the system.");
        }
        return dealers;
    }

    // Update The Dealer By Dealer Id
    @Override
    public Dealer updateDealer(Long dealerId, Dealer dealer) {
        log.info("Updating dealer with ID: {}", dealerId);
        Dealer existingDealer = getDealerById(dealerId);
        existingDealer.setContactNumber(dealer.getContactNumber());
        return dealerRepository.save(existingDealer);
    }

    // Delete The Dealer with the Dealer Id
    @Override
    public void deleteDealer(Long dealerId) {
        log.info("Deleting dealer with ID: {}", dealerId);
        Dealer dealer = dealerRepository.findById(dealerId)
                .orElseThrow(() -> new EntryNotFound("Dealer not found with ID: " + dealerId));
        dealerRepository.delete(dealer);
    }

    // Find All the Crops from Farmer Microservice
    @Override
    public List<CropDTO> viewAllCrops() {
        log.info("Fetching all crops from farmer microservice");
        return farmerClient.getallcrops();
    }

    // Find The Crops for Farmer Microservice
    @Override
    public Object getCropDetailsForFarmer(Long farmerId) {
        log.info("Fetching crop details for farmer with ID: {}", farmerId);
        return farmerClient.getCropDetailsForFarmer(farmerId);
    }

    // Get Farmer Details for Crop From Farmer Microservice
    @Override
    public Object getFarmerDetailsForCrop(Long cropId) {
        log.info("Fetching farmer details for crop with ID: {}", cropId);
        return farmerClient.getFarmerDetailsForCrop(cropId);
    }

    // Get Crop By Crop Name From Farmer Microservice
    @Override
    public List<CropDTO> getCropsByName(String cropName) {
        log.info("Fetching crops by name: {}", cropName);
        return farmerClient.getCropsByName(cropName);
    }

    // Add Crops In the Dealers Cart List with By Crop Id and Dealer Id
    @Override
    public CartItem addItemInCart(Long cropId, Long dealerId) {
        log.info("Adding crop with ID: {} to dealer's cart with dealer ID: {}", cropId, dealerId);
        CartItem item = farmerClient.getCropById(cropId);

        Dealer dealer = dealerRepository.findById(dealerId)
                .orElseThrow(() -> new EntryNotFound("Dealer not found with ID: " + dealerId));

       // List<CartItem> cart = dealer.getDealerCart();

        boolean alreadyExists = dealer.getDealerCart().stream()
                .anyMatch(existingItem -> existingItem.getCropId().equals(cropId));

        if (alreadyExists) {
            log.warn("Crop with ID {} already exists in the cart of dealer {}", cropId, dealerId);
            throw new DuplicateException("Crop with ID " + cropId + " is already in the cart.");
        }

        dealer.getDealerCart().add(item);
      //  dealerRepository.save(dealer);
        return cartItemRepository.save(item);
    }

    // Delete The crop from the Dealer's Cart By Crop Id and Dealer Id
    @Override
    public boolean deleteItemFromCart(Long cropId, Long dealerId) {
        log.info("Deleting crop with ID: {} from dealer's cart with dealer ID: {}", cropId, dealerId);
        Dealer dealer = dealerRepository.findById(dealerId)
                .orElseThrow(() -> new EntryNotFound("Dealer not found with ID: " + dealerId));

        List<CartItem> cart = dealer.getDealerCart();
        CartItem itemToRemove = null;

        for (CartItem item : cart) {
            if (item.getCropId().equals(cropId)) {
                itemToRemove = item;
                break;
            }
        }

        if (itemToRemove != null) {
            cart.remove(itemToRemove);
            cartItemRepository.delete(itemToRemove);
            dealerRepository.save(dealer);
            return true;
        } else {
            log.warn("Crop not found in dealer's cart with Crop ID: {}", cropId);
            throw new EntryNotFound("Crop not found in dealer's cart with Crop ID: " + cropId);
        }
    }

    // Find The cartlist of the dealer with the Dealer Id
    @Override
    public List<CartItem> getAllCartByDealer(Long dealerId) {
        log.info("Fetching cart list for dealer ID: {}", dealerId);
        Dealer dealer = dealerRepository.findById(dealerId)
                .orElseThrow(() -> new EntryNotFound("Dealer not found with ID: " + dealerId));
        return dealer.getDealerCart();
    }

    // Empty the Cart Of the dealer By Dealer Id After payment Successful
    @Override
    public String emptyCartList(Long dealerId) {
        log.info("Emptying cart for dealer ID: {}", dealerId);
        Dealer dealer = dealerRepository.findById(dealerId)
                .orElseThrow(() -> new EntryNotFound("Dealer not found with ID: " + dealerId));
        dealer.getDealerCart().clear();
        dealerRepository.save(dealer);
        return "Dealer's cart list is empty for id " + dealerId;
    }

    // Calculate Total Amount in The Dealer's Cart By Id
    @Override
    public double calculateTotalAmountInCart(Long dealerId) {
        log.info("Calculating total amount in cart for dealer ID: {}", dealerId);
        Dealer dealer = dealerRepository.findById(dealerId)
                .orElseThrow(() -> new EntryNotFound("Dealer not found with ID: " + dealerId));
        List<CartItem> cartItems = dealer.getDealerCart();
        double totalAmount = 0;
        for (CartItem item : cartItems) {
            totalAmount += item.getPricePerKg() * item.getQuantityAvailable();
        }
        log.info("Total amount calculated: {}", totalAmount);
        return totalAmount;
    }

    // Delete a Dealer By Email
    @Override
    @Transactional
    public String deleteByEmail(String email) {
        log.info("Deleting dealer with email: {}", email);
        dealerRepository.deleteByEmail(email);
        return "User deleted Successfully with email " + email;
    }
}
