package com.dealer.Dealer_service.ExceptionHandle;

public class EntryNotFound extends RuntimeException {
    public EntryNotFound(String message) {
        super(message);
    }
}
