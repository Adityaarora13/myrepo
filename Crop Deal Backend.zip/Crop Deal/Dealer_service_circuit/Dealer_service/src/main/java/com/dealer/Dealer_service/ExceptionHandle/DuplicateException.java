package com.dealer.Dealer_service.ExceptionHandle;

public class DuplicateException extends RuntimeException {
    public DuplicateException(String message) {
        super(message);
    }
}
