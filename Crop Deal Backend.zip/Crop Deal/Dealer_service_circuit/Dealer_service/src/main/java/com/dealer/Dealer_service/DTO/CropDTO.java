package com.dealer.Dealer_service.DTO;

import jakarta.persistence.ElementCollection;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CropDTO {
    private Long cropId;
    private String cropName;
    private String cropType;
    private Double pricePerKg;
    private Long quantityAvailable;
    private Long farmer_id_display;

}
