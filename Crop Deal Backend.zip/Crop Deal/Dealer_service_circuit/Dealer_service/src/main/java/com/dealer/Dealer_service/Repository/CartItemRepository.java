package com.dealer.Dealer_service.Repository;

import com.dealer.Dealer_service.Model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface
CartItemRepository extends JpaRepository<CartItem,Long> {
}
