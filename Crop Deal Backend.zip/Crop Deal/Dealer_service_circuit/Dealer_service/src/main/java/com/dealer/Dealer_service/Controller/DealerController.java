package com.dealer.Dealer_service.Controller;

import com.dealer.Dealer_service.DTO.CropDTO;
import com.dealer.Dealer_service.Model.CartItem;
import com.dealer.Dealer_service.Model.Dealer;
import com.dealer.Dealer_service.Service.DealerService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/dealer")
@RequiredArgsConstructor
public class DealerController {

    @Autowired
    private final DealerService dealerService;

    private final Logger logger = LoggerFactory.getLogger(DealerController.class);

    // Add Dealer
    @PostMapping("/add")
    public ResponseEntity<?> createDealer(@RequestBody Dealer dealer) {
        logger.info("Creating dealer with email: {}", dealer.getEmail());
        return ResponseEntity.ok(dealerService.createDealer(dealer));
    }

    // find dealer by dealer email
    @GetMapping("/{emailId}")
    public ResponseEntity<?> getDealerByEmail(@PathVariable String emailId) {
        logger.info("Fetching dealer by email: {}", emailId);
        return ResponseEntity.ok(dealerService.getDealerByEmail(emailId));
    }

    // find dealer by dealer Id
    @GetMapping("/dealer/{dealerId}")
    public ResponseEntity<?> getDealerById(@PathVariable Long dealerId) {
        logger.info("Fetching dealer by ID: {}", dealerId);
        return ResponseEntity.ok(dealerService.getDealerById(dealerId));
    }

    // Get All the Dealers
    @GetMapping("/all")
    public ResponseEntity<?> getAllDealers() {
        logger.info("Fetching all dealers");
        return ResponseEntity.ok(dealerService.getAllDealers());
    }

    // Edit The Dealer with Dealer Id
    @PutMapping("/edit/{dealerId}")
    public ResponseEntity<?> updateDealer(@PathVariable Long dealerId, @RequestBody Dealer dealer) {
        logger.info("Updating dealer with ID: {}", dealerId);
        return ResponseEntity.ok(dealerService.updateDealer(dealerId, dealer));
    }

    // delete Dealer By Dealer Id
    @DeleteMapping("/delete/{dealerId}")
    public ResponseEntity<?> deleteDealer(@PathVariable Long dealerId) {
        // Dealer dealer=dealerService.getDealerById(dealerId);
        logger.info("Deleting dealer with ID: {}", dealerId);
        dealerService.deleteDealer(dealerId);
        logger.info("Dealer with ID {} deleted", dealerId);
        return ResponseEntity.ok("Dealer deleted successfully.");
    }

    // Delete Dealer By Email
    @DeleteMapping("delete/email/{email}")
    public ResponseEntity<?> deletebyemail(@PathVariable String email) {
        logger.info("Deleting dealer by email: {}", email);
        String response = dealerService.deleteByEmail(email);
        logger.info("Dealer with email {} deleted", email);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // Get The cartlist of the dealer
    @GetMapping("/cart/{dealerId}")
    public ResponseEntity<?> getCartlistByDealerId(@PathVariable Long dealerId) {
        logger.info("Fetching cart list for dealer ID: {}", dealerId);
        return ResponseEntity.ok(dealerService.getAllCartByDealer(dealerId));
    }

    // Make the cartlist of the dealer Empty with dealer Id
    @DeleteMapping("/cart/empty/{dealerId}")
    public ResponseEntity<?> emptyCartList(@PathVariable Long dealerId) {
        logger.info("Emptying cart for dealer ID: {}", dealerId);
        return ResponseEntity.ok(dealerService.emptyCartList(dealerId));
    }

    // Add Item in cart by dealer Id crop Id
    @PostMapping("/item/{dealerId}/{cropId}")
    public ResponseEntity<?> addItemInCart(@PathVariable Long dealerId, @PathVariable Long cropId) {
        logger.info("Adding crop ID {} to cart of dealer ID {}", cropId, dealerId);
        return ResponseEntity.ok(dealerService.addItemInCart(cropId, dealerId));
    }

    // Delete Crop from the dealer's cart list with Crop Id
    @DeleteMapping("/item/{dealerId}/{cropId}")
    public ResponseEntity<?> deleteItemFromCart(@PathVariable Long dealerId, @PathVariable Long cropId) {
        logger.info("Deleting crop ID {} from cart of dealer ID {}", cropId, dealerId);
        boolean deleted = dealerService.deleteItemFromCart(cropId, dealerId);
        if (deleted) {
            logger.info("Crop ID {} deleted from cart of dealer ID {}", cropId, dealerId);
            return ResponseEntity.ok("Item deleted from cart successfully.");
        } else {
            logger.warn("Crop ID {} not found in cart of dealer ID {}", cropId, dealerId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Item not found in cart.");
        }
    }

    // Get All the Crops
    @GetMapping("/crops")
    public ResponseEntity<?> getall() {
        logger.info("Fetching all crops");
        return ResponseEntity.ok(dealerService.viewAllCrops());
    }

    // Get Crops By Crop Name
    @GetMapping("/crops/{cropName}")
    public ResponseEntity<?> getcropsByName(@PathVariable String cropName) {
        logger.info("Fetching crops by name: {}", cropName);
        return ResponseEntity.ok(dealerService.getCropsByName(cropName));
    }

    // Get Farmer Details for the particular crop id
    @GetMapping("/farmer/{cropId}")
    @CircuitBreaker(name = "farmerServiceBreaker", fallbackMethod = "farmerFallback")
    public ResponseEntity<Object> getFarmerDetailsForCrop(@PathVariable Long cropId) {
        // try {
        logger.info("Calling farmer service for crop ID {}", cropId);
        Object response = dealerService.getFarmerDetailsForCrop(cropId);
        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    // Get all the crop details by farmer Id
    @GetMapping("/crop/{farmerId}")
    @CircuitBreaker(name = "farmerServiceBreaker", fallbackMethod = "cropFallback")
    public ResponseEntity<Object> getCropDetailsForFarmer(@PathVariable Long farmerId) {
        // try {
        logger.info("Calling crop service for farmer ID {}", farmerId);
        Object response = dealerService.getCropDetailsForFarmer(farmerId);
        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    // Calculate Total Amount In the Cart of Dealer By Dealer Id
    @GetMapping("/price/{dealerId}")
    public ResponseEntity<?> getTotalAmountInCart(@PathVariable Long dealerId) {
        logger.info("Calculating total amount in cart for dealer ID {}", dealerId);
        double totalAmount = dealerService.calculateTotalAmountInCart(dealerId);
        logger.debug("Total amount for dealer ID {} is {}", dealerId, totalAmount);
        return ResponseEntity.ok(totalAmount);
    }

    // Fallback method for Farmer
    public ResponseEntity<Object> farmerFallback(Long cropId, Throwable t) {
        // logger.error("Farmer Service is down. Returning fallback for cropId {}", cropId);
        logger.error("Farmer service down for cropId {}. Error: {}", cropId, t.getMessage());
        return new ResponseEntity<>("Farmer Service is unavailable. Please try again later message from fallback method", HttpStatus.SERVICE_UNAVAILABLE);
    }

    // Fallback method for Crop
    public ResponseEntity<Object> cropFallback(Long farmerId, Throwable t) {
        // logger.error("Farmer Service is down. Returning fallback for farmerId {}", farmerId);
        logger.error("Crop service down for farmerId {}. Error: {}", farmerId, t.getMessage());
        return new ResponseEntity<>("Farmer Service is unavailable. Please try again later method from fallback method ", HttpStatus.SERVICE_UNAVAILABLE);
    }

}
