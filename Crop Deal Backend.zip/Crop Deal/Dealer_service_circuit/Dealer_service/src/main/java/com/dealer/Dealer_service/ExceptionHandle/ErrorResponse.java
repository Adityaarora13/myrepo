package com.dealer.Dealer_service.ExceptionHandle;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
// response class for handle feign exception response
public class ErrorResponse {
    private int status;
    private String message;
}
