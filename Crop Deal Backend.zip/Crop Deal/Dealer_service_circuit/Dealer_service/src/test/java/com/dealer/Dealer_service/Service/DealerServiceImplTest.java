package com.dealer.Dealer_service.Service;

import com.dealer.Dealer_service.DTO.CropDTO;
import com.dealer.Dealer_service.ExceptionHandle.EntryNotFound;
import com.dealer.Dealer_service.Model.CartItem;
import com.dealer.Dealer_service.Model.Dealer;
import com.dealer.Dealer_service.Repository.CartItemRepository;
import com.dealer.Dealer_service.Repository.DealerRepository;
import com.dealer.Dealer_service.Service.Implemetation.DealerServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DealerServiceImplTest {

    @Mock  private DealerRepository   dealerRepository;
    @Mock  private CartItemRepository cartItemRepository;
    @Mock  private FarmerClient       farmerClient;

    @InjectMocks
    private DealerServiceImpl dealerService;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    /* ---------- CREATE ---------- */

    @Test
    void createDealer_savesAndReturnsDealer() {
        Dealer dealer = new Dealer(1L, "John", "john@ex.com", "999", null);
        when(dealerRepository.save(dealer)).thenReturn(dealer);

        Dealer saved = dealerService.createDealer(dealer);

        assertEquals(dealer, saved);
        verify(dealerRepository).save(dealer);
    }

    /* ---------- READ ---------- */

    @Test
    void getDealerById_returnsDealer() {
        Dealer dealer = new Dealer(1L, "John", null, null, null);
        when(dealerRepository.findById(1L)).thenReturn(Optional.of(dealer));

        Dealer found = dealerService.getDealerById(1L);

        assertSame(dealer, found);
        verify(dealerRepository).findById(1L);
    }

    @Test
    void getDealerById_throwsWhenMissing() {
        when(dealerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EntryNotFound.class,
                () -> dealerService.getDealerById(1L));
    }

    /* ---------- UPDATE ---------- */

    @Test
    void updateDealer_updatesContactNumberOnly() {
        Dealer existing = new Dealer(1L, "Name", "mail@ex.com", "0000", null);
        Dealer patch    = new Dealer(null, "IGNORED", "IGNORED", "1234", null);

        when(dealerRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(dealerRepository.save(any(Dealer.class)))
                .thenAnswer(i -> i.getArgument(0));   // echo‑back

        Dealer updated = dealerService.updateDealer(1L, patch);

        assertEquals("1234", updated.getContactNumber());
        assertEquals("Name",  updated.getName());          // unchanged
        assertEquals("mail@ex.com", updated.getEmail());   // unchanged
        verify(dealerRepository).save(existing);
    }

    /* ---------- DELETE ---------- */

    @Test
    void deleteDealer_deletesLoadedEntity() {
        Dealer dealer = new Dealer(1L, "John", null, null, null);
        when(dealerRepository.findById(1L)).thenReturn(Optional.of(dealer));

        dealerService.deleteDealer(1L);

        verify(dealerRepository).delete(dealer);
        verify(dealerRepository, never()).deleteById(anyLong());
    }

    @Test
    void deleteDealer_throwsWhenMissing() {
        when(dealerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EntryNotFound.class,
                () -> dealerService.deleteDealer(1L));
        verify(dealerRepository, never()).delete(any());
    }

    /* ---------- LIST / VIEW ---------- */

    @Test
    void getAllDealers_returnsList() {
        List<Dealer> list = Arrays.asList(new Dealer(), new Dealer());
        when(dealerRepository.findAll()).thenReturn(list);

        List<Dealer> result = dealerService.getAllDealers();

        assertEquals(2, result.size());
    }

    @Test
    void getAllDealers_throwsWhenEmpty() {
        when(dealerRepository.findAll()).thenReturn(Collections.emptyList());

        assertThrows(EntryNotFound.class, dealerService::getAllDealers);
    }

    @Test
    void viewAllCrops_returnsFromClient() {
        List<CropDTO> crops = Arrays.asList(new CropDTO(), new CropDTO());
        when(farmerClient.getallcrops()).thenReturn(crops);

        assertEquals(2, dealerService.viewAllCrops().size());
    }

    /* ---------- CART ---------- */

    // Add Item in Cart
    @Test
    void addItemInCart_addsWhenNotDuplicate() {
        long dealerId = 1L, cropId = 99L;
        CartItem item = new CartItem(); item.setCropId(cropId);

        Dealer dealer = new Dealer();
        dealer.setDealerCart(new ArrayList<>());

        when(farmerClient.getCropById(cropId)).thenReturn(item);
        when(dealerRepository.findById(dealerId)).thenReturn(Optional.of(dealer));
        when(cartItemRepository.save(item)).thenReturn(item);

        CartItem saved = dealerService.addItemInCart(cropId, dealerId);

        assertSame(item, saved);
        verify(cartItemRepository).save(item);
        assertEquals(1, dealer.getDealerCart().size());
    }

    // Find Dealer By Email
    @Test
    void getDealerByEmail_shouldReturnDealer() {
        Dealer dealer = new Dealer(1L, "Dealer", "dealer@example.com", "9999", null);
        when(dealerRepository.findByEmail("dealer@example.com")).thenReturn(Optional.of(dealer));

        Dealer result = dealerService.getDealerByEmail("dealer@example.com");

        assertEquals("Dealer", result.getName());
        verify(dealerRepository).findByEmail("dealer@example.com");
    }


    // Find Dealer By Email when dealer not found
    @Test
    void getDealerByEmail_shouldThrowIfNotFound() {
        when(dealerRepository.findByEmail("notfound@example.com")).thenReturn(Optional.empty());

        assertThrows(EntryNotFound.class, () -> dealerService.getDealerByEmail("notfound@example.com"));
    }

    //Find Crop Details
    @Test
    void getCropDetailsForFarmer_shouldCallClient() {
        when(farmerClient.getCropDetailsForFarmer(5L)).thenReturn("CropDetails");

        Object result = dealerService.getCropDetailsForFarmer(5L);

        assertEquals("CropDetails", result);
        verify(farmerClient).getCropDetailsForFarmer(5L);
    }

    // Find Farmer Details
    @Test
    void getFarmerDetailsForCrop_shouldCallClient() {
        when(farmerClient.getFarmerDetailsForCrop(10L)).thenReturn("FarmerDetails");

        Object result = dealerService.getFarmerDetailsForCrop(10L);

        assertEquals("FarmerDetails", result);
        verify(farmerClient).getFarmerDetailsForCrop(10L);
    }

    // Delete Item from Dealer Cart
    @Test
    void deleteItemFromCart_shouldRemoveItem() {
        CartItem item = new CartItem();
        item.setCropId(10L);

        Dealer dealer = new Dealer();
        List<CartItem> cart = new ArrayList<>();
        cart.add(item);
        dealer.setDealerCart(cart);

        when(dealerRepository.findById(1L)).thenReturn(Optional.of(dealer));

        boolean result = dealerService.deleteItemFromCart(10L, 1L);

        assertTrue(result);
        assertTrue(dealer.getDealerCart().isEmpty());
        verify(cartItemRepository).delete(item);
        verify(dealerRepository).save(dealer);
    }


    // Delete Item from Dealer Cart When Item not found
    @Test
    void deleteItemFromCart_shouldThrowIfNotFound() {
        CartItem item = new CartItem(); item.setCropId(99L);
        Dealer dealer = new Dealer();
        dealer.setDealerCart(new ArrayList<>());

        when(dealerRepository.findById(1L)).thenReturn(Optional.of(dealer));

        assertThrows(EntryNotFound.class, () -> dealerService.deleteItemFromCart(99L, 1L));
    }

    // Empty Cart List
    @Test
    void emptyCartList_shouldClearCart() {
        CartItem item = new CartItem();
        Dealer dealer = new Dealer();
        dealer.setDealerCart(new ArrayList<>(List.of(item)));

        when(dealerRepository.findById(1L)).thenReturn(Optional.of(dealer));

        String message = dealerService.emptyCartList(1L);

        assertEquals("Dealer's cart list is empty for id 1", message);
        assertTrue(dealer.getDealerCart().isEmpty());
        verify(dealerRepository).save(dealer);
    }


    // Delete By Email
    @Test
    void deleteByEmail_shouldCallDeleteAndReturnMessage() {
        String email = "test@example.com";

        String result = dealerService.deleteByEmail(email);

        assertEquals("User deleted Successfully with email " + email, result);
        verify(dealerRepository).deleteByEmail(email);
    }



}
