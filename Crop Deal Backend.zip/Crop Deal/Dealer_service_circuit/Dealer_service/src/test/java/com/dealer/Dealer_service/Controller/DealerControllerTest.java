package com.dealer.Dealer_service.Controller;

import com.dealer.Dealer_service.DTO.CropDTO;
import com.dealer.Dealer_service.Model.CartItem;
import com.dealer.Dealer_service.Model.Dealer;
import com.dealer.Dealer_service.Service.DealerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(DealerController.class)
class DealerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DealerService dealerService;

    private Dealer dealer;
    private CropDTO cropDTO;
    private CartItem cartItem;

    @BeforeEach
    void setUp() {
        dealer = new Dealer();
        dealer.setDealerId(1L);
        dealer.setName("John");

        cropDTO = new CropDTO();
        cropDTO.setCropId(100L);
        cropDTO.setCropName("Wheat");

        cartItem = new CartItem();
        cartItem.setCartItemId(1L);
        cartItem.setCropId(100L);
    }

    @Test
    void testCreateDealer() throws Exception {
        Mockito.when(dealerService.createDealer(Mockito.any(Dealer.class))).thenReturn(dealer);

        mockMvc.perform(post("/api/dealer/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"dealerName\": \"John\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John"));
    }

    @Test
    void testGetDealerById() throws Exception {
        Mockito.when(dealerService.getDealerById(1L)).thenReturn(dealer);

        mockMvc.perform(get("/api/dealer/dealer/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John"));
    }

    @Test
    void testGetAllDealers() throws Exception {
        Mockito.when(dealerService.getAllDealers()).thenReturn(List.of(dealer));

        mockMvc.perform(get("/api/dealer/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("John"));
    }

    @Test
    void testAddItemInCart() throws Exception {
        Mockito.when(dealerService.addItemInCart(100L, 1L)).thenReturn(cartItem);

        mockMvc.perform(post("/api/dealer/item/1/100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cropId").value(100));
    }

    @Test
    void testGetCropsByName() throws Exception {
        Mockito.when(dealerService.getCropsByName("Wheat")).thenReturn(List.of(cropDTO));

        mockMvc.perform(get("/api/dealer/crops/Wheat"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].cropName").value("Wheat"));
    }

    @Test
    void testGetTotalAmountInCart() throws Exception {
        Mockito.when(dealerService.calculateTotalAmountInCart(1L)).thenReturn(123.45);

        mockMvc.perform(get("/api/dealer/price/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("123.45"));
    }


}
