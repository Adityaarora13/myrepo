package com.example.Authentication.client;

import com.example.Authentication.DTO.DealerDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
@Component@FeignClient(name = "DEALERSERVICE")
public interface DealerClient {
    @PostMapping("/api/dealer/add")
    DealerDto createDealer(DealerDto dealer);
}
