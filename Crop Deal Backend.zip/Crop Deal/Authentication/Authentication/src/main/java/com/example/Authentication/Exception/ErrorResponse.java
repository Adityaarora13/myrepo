package com.example.Authentication.Exception;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
// response class for handle feign exception response
public class ErrorResponse {
    private int status;
    private String message;
}
