// path: com.example.Authentication.Exception.UserAlreadyExistsException.java
package com.example.Authentication.Exception;

public class UserAlreadyExistsException extends RuntimeException {
    public UserAlreadyExistsException(String message) {
        super(message);
    }
}
