package com.example.Authentication.Model;

public enum Role {
    FARMER,
    DEALER,
    ADMIN
}
