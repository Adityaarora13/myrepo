package com.example.Authentication.Controller;

import com.example.Authentication.Model.User;
import com.example.Authentication.Services.AuthenticationService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/user")
@AllArgsConstructor
public class UserController {

    private final AuthenticationService authenticationService;

    @PreAuthorize("ADMIN")
    @DeleteMapping("/delete/farmer/{email}")
    public ResponseEntity<String> deleteFarmer(@PathVariable String email){
        authenticationService.DeleteFarmerEmail(email);
        return new ResponseEntity<>("User deleted Successfully!!" , HttpStatus.OK);
    }

    @PreAuthorize("ADMIN")
    @DeleteMapping("/delete/dealer/{email}")
    public ResponseEntity<String> deleteDealer(@PathVariable String email){
        authenticationService.DeleteDealerEmail(email);
        return new ResponseEntity<>("User deleted Successfully!!" , HttpStatus.OK);
    }

    @PreAuthorize("ADMIN")
    @GetMapping("/all")
    public ResponseEntity<List<User>> getalluser(){
        return new ResponseEntity<>(authenticationService.getAllusers(),HttpStatus.OK);
    }

    @PreAuthorize("ADMIN")
    @GetMapping("/{Id}")
    public ResponseEntity<Optional<User>> getUserByID(@PathVariable Long Id){
        return new ResponseEntity<>(authenticationService.getUserById(Id) , HttpStatus.OK);
    }
}
