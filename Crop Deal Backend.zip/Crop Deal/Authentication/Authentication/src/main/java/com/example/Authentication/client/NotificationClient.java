package com.example.Authentication.client;


import com.example.Authentication.DTO.WelcomeDto;
import com.example.Authentication.DTO.loginDto;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "NOTIFICATIONSERVICE")
public interface NotificationClient {

    @PostMapping("/api/notifications/welcome")
    void sendWelcome(@RequestBody WelcomeDto welcomeDto);

    @PostMapping("/api/notifications/login")
    void sendLogin(@RequestBody loginDto loginDto);
}
