package com.example.Authentication.DTO;

import lombok.Data;

@Data
public class RefreshTokenRequest {
    private String token;
}
