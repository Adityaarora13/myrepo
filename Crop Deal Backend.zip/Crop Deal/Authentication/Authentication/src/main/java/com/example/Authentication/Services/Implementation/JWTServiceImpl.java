package com.example.Authentication.Services.Implementation;

import com.example.Authentication.Model.User;
import com.example.Authentication.Services.JWTService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

@Service
public class JWTServiceImpl  implements  JWTService{

    public String generateToken(UserDetails userDetails){

//        Token ke andar daalne wale extra info (custom claims) ke liye map banaya.
        Map<String , Object> claims = new HashMap<>();


        // fetch user authorities other wise default farmer
        String role = userDetails.getAuthorities().stream().findFirst().map(Object::toString).orElse("FARMER");

        claims.put("role" , role);
        // token ko build krke return kr diya
        return Jwts.builder().setClaims(claims).
                setSubject(userDetails.getUsername())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 1000*24*60*60)) //one day
                .signWith(getSigninKey() , SignatureAlgorithm.HS256)
                .compact();
    }

    public String generateRefreshToken(Map< String , Object> extraclaims , UserDetails userDetails){
        return Jwts.builder().setClaims(extraclaims).setSubject(userDetails.getUsername())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 604800000)) //7 days
                .signWith(getSigninKey() , SignatureAlgorithm.HS256)
                .compact();
    }


    //generate the sign in key
    private Key getSigninKey(){
        byte[] key = Decoders.BASE64.decode("2345678weewewe9ioiuytrdfghjikjhgytr56tyuijhgfxd"); //this here is our secret key
        return Keys.hmacShaKeyFor(key);
    }

    //extract the name
//    Token ke andar se koi bhi specific claim extract karne ke liye reusable method.
//
//    Generic hai: aap getSubject, getExpiration, ya custom fields sab nikal sakte ho.

    private <T> T extractClaims(String token, Function<Claims,T> claimsResolvers){
        final Claims claims = extractAllClaims(token);
        return claimsResolvers.apply(claims);
    }

    //extract all the claims
//    JWT ke andar ke saare claims (key-value data) nikalta hai after verifying the token using signing key.
    private Claims extractAllClaims(String token) {
         return Jwts.parserBuilder().setSigningKey(getSigninKey()).build().parseClaimsJws(token).getBody();
    }

    //extract the username
    public String extractusername(String token){
        return extractClaims(token , Claims::getSubject);
    }

    public boolean isTokenValid (String token, UserDetails userDetails){
        final String username = extractusername(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }

    public String extractRole(String token){
        return extractClaims(token , claims -> claims.get("role" , String.class));
    }



    private boolean isTokenExpired(String token){
        return extractClaims(token , Claims::getExpiration).before(new Date());
    }

}
