package com.example.Authentication.Controller;


import com.example.Authentication.DTO.JwtAuthResponse;
import com.example.Authentication.DTO.RefreshTokenRequest;
import com.example.Authentication.DTO.SignUpRequest;
import com.example.Authentication.DTO.SigninRequest;
import com.example.Authentication.Model.User;
import com.example.Authentication.Services.AuthenticationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class Authcontroller {

    private final AuthenticationService authenticationService;


    @PostMapping("/signup")
    public ResponseEntity<Map<String, String>> signup(@RequestBody @Valid SignUpRequest signUpRequest) {
        authenticationService.Signup(signUpRequest);
        return ResponseEntity.ok(Map.of("message", "User Registered Successfully!!"));
    }



    @PostMapping("/signin")
    public ResponseEntity<JwtAuthResponse> signup(@RequestBody @Valid SigninRequest signinRequest){
        return ResponseEntity.ok(authenticationService.signin(signinRequest));
    }


    @PostMapping("/refresh")
    public ResponseEntity<JwtAuthResponse> refreshtoken(@RequestBody RefreshTokenRequest refreshTokenRequest){
        return ResponseEntity.ok(authenticationService.refreshToken(refreshTokenRequest));
    }
}
