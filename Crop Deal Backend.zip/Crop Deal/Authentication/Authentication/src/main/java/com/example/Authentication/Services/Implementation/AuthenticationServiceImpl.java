package com.example.Authentication.Services.Implementation;

import com.example.Authentication.DTO.*;
import com.example.Authentication.Exception.InvalidCredentials;
import com.example.Authentication.Exception.UserAlreadyExistsException;
import com.example.Authentication.Exception.UserNotFound;
import com.example.Authentication.Model.Role;
import com.example.Authentication.Model.User;
import com.example.Authentication.Repository.UserRepository;
import com.example.Authentication.Services.AuthenticationService;
import com.example.Authentication.Services.JWTService;
import com.example.Authentication.client.DealerClient;
import com.example.Authentication.client.FarmerClient;
import com.example.Authentication.client.NotificationClient;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.*;

import java.util.HashMap;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {

    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;
//    A Spring Security component for encoding (hashing)
//    passwords securely (e.g., using BCrypt). Injected and immutable.

    private final AuthenticationManager authenticationManager;

    private  final JWTService jwtService;

//    A Spring Security component responsible for authenticating users
//    based on credentials (e.g., email and password). Injected and immutable
//
//    jwtService: A custom service for generating and
//    validating JWTs (access and refresh tokens). Injected and immutable.
//
    @Autowired
    FarmerClient farmerClient;

    @Autowired
    DealerClient dealerClient;

    @Autowired
    NotificationClient notificationClient;
    public User Signup(SignUpRequest signUpRequest){
        //  Check if user already exists
        Optional<?> already=userRepository.findByEmail(signUpRequest.getEmail());
        if (!already.isEmpty()) {
            throw new UserAlreadyExistsException("User with this email: "+signUpRequest.getEmail()+" already exists");
        }

        User user = new User();
        user.setEmail(signUpRequest.getEmail());
        user.setFirstname(signUpRequest.getFirstName());
        user.setLastname(signUpRequest.getLastName());
        user.setRole(signUpRequest.getRole());
        user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));

        if(signUpRequest.getRole().name().equals("ADMIN")){
            throw new UserAlreadyExistsException("Admin Already exists can't have multiple admins");
        }

       else if(signUpRequest.getRole().name().equals("FARMER")){
            FarmerDto farmerDto=new FarmerDto(signUpRequest.getFirstName()+" "+signUpRequest.getLastName(),signUpRequest.getEmail());
            farmerClient.saveFarmer(farmerDto);
        }

        else if(signUpRequest.getRole().name().equals("DEALER")){
            DealerDto dealerDto=new DealerDto(signUpRequest.getFirstName()+" "+signUpRequest.getLastName(),signUpRequest.getEmail());
            dealerClient.createDealer(dealerDto);
        }
        WelcomeDto welcomeDto = new WelcomeDto();
        welcomeDto.setEmail(signUpRequest.getEmail());
        welcomeDto.setName(signUpRequest.getFirstName());

        notificationClient.sendWelcome(welcomeDto);

        return userRepository.save(user);
    }

    public JwtAuthResponse signin(SigninRequest signinRequest){
        //validate the username and password;
        try{
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(signinRequest.getEmail() , signinRequest.getPassword()));
        }
        catch (BadCredentialsException ex){
            throw new InvalidCredentials("Invalid Email or Password");
        }

        // var is used to to store the result according to the return type

        // Ex-> User user = userRepository.findByEmail(email).orElseThrow();
        //String token = jwtService.generateToken(user);

//        var user = userRepository.findByEmail(email).orElseThrow();
//        var token = jwtService.generateToken(user); both are same




        var user =userRepository.findByEmail(signinRequest.getEmail()).orElseThrow(()->new InvalidCredentials("Please check your  email or password"));
        var jwtToken = jwtService.generateToken(user);
        var refreshToken = jwtService.generateRefreshToken(new HashMap<>() , user);

        JwtAuthResponse response = new JwtAuthResponse();
        response.setToken(jwtToken);
        response.setRefreshToken(refreshToken);

        loginDto loginDto=new loginDto();
        loginDto.setEmail(signinRequest.getEmail());
        notificationClient.sendLogin(loginDto);

        return response;

    }


    public JwtAuthResponse refreshToken(RefreshTokenRequest refreshTokenRequest){
        String userEmail = jwtService.extractusername(refreshTokenRequest.getToken());
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        if (jwtService.isTokenValid(refreshTokenRequest.getToken() , user)){
            var jwtToken = jwtService.generateToken(user);
            JwtAuthResponse response = new JwtAuthResponse();
            response.setToken(jwtToken);
            response.setRefreshToken(refreshTokenRequest.getToken());
            return response;
        }
        return null;
    }

    @Override
    @Transactional
    public String DeleteFarmerEmail(String farmerEmail) {
        Optional<User> useralready =  userRepository.findByEmail(farmerEmail);
        if (!useralready.isPresent()){
            throw new UserNotFound("User with email :"+farmerEmail+" not present !");
        }
//        userRepository.deleteById(useralready.get().getId());
        userRepository.deleteByEmail(farmerEmail);
        return "User deleted Successfully";
    }

    // Delete Dealer With Email Id
    @Override
    @Transactional
    public String DeleteDealerEmail(String DealerEmail) {
        Optional<User> useralready =  userRepository.findByEmail(DealerEmail);
        if (!useralready.isPresent()){
            throw new UserNotFound("User with email: "+DealerEmail+" not present !");
        }
//        userRepository.deleteById(useralready.get().getId());
        userRepository.deleteByEmail(DealerEmail);
        return "User deleted Successfully";
    }

    @Override
    public List<User> getAllusers() {
        List<User>users=userRepository.findAll();
        if(users.isEmpty()){
            throw new UserNotFound("No users registered in the Application !");
        }
        return users;
    }

//    @Override
//    public Optional<User> getUserById(Long id) {
//        return userRepository.findById(id);
//    }

    @Override
    public Optional<User> getUserById(Long id) {
        Optional<User>userOptional= userRepository.findById(id);
        if(userOptional.isPresent()){
            return userOptional;
        }
        throw new UserNotFound("User with id " + id + " not found");

    }


}
