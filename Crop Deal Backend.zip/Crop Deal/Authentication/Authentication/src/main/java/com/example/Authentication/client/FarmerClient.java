package com.example.Authentication.client;

import com.example.Authentication.DTO.FarmerDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
@Component@FeignClient(name = "FARMERSERVICE")
public interface FarmerClient {
    @PostMapping("/api/farmer")
    FarmerDto saveFarmer(FarmerDto farmer);
}
