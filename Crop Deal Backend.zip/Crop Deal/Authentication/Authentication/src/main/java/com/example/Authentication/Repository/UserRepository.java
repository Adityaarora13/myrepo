package com.example.Authentication.Repository;

import com.example.Authentication.Model.Role;
import com.example.Authentication.Model.User;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User , Long> {
    Optional<User> findByEmail(String email);
    User findByRole(Role role);
    @Transactional
    String deleteByEmail(String email);
}
