package com.example.Authentication.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data@NoArgsConstructor
@AllArgsConstructor
public class DealerDto {
    private String name;
    private String email;
}
