package com.example.Authentication.Services;

import com.example.Authentication.DTO.JwtAuthResponse;
import com.example.Authentication.DTO.RefreshTokenRequest;
import com.example.Authentication.DTO.SignUpRequest;
import com.example.Authentication.DTO.SigninRequest;
import com.example.Authentication.Model.User;

import java.util.List;
import java.util.Optional;

public interface AuthenticationService {
    User Signup(SignUpRequest signUpRequest) ;
    JwtAuthResponse signin(SigninRequest signinRequest);
    JwtAuthResponse refreshToken(RefreshTokenRequest refreshTokenRequest);
    String DeleteFarmerEmail(String farmerEmail);
    String DeleteDealerEmail(String dealerEmail);
    List<User> getAllusers();
    Optional<User> getUserById(Long id);
}
