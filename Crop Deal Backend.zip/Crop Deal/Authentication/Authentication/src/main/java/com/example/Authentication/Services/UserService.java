package com.example.Authentication.Services;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService {

     UserDetailsService userDetailsService();
    }
