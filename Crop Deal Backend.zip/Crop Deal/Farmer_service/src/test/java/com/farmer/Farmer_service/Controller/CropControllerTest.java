package com.farmer.Farmer_service.Controller;

import com.farmer.Farmer_service.Service.Interface.CropService;
import com.farmer.Farmer_service.Model.Crop;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class CropControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CropService cropService;

    @InjectMocks
    private CropController cropController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(cropController).build();
    }

    @Test
    public void testAddCrop() throws Exception {
        Crop crop = new Crop();
        crop.setCropName("Wheat");
        when(cropService.addCrop(anyLong(), any(Crop.class))).thenReturn(crop);

        mockMvc.perform(post("/api/crops/farmer/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"cropName\":\"Wheat\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cropName").value("Wheat"));

        verify(cropService, times(1)).addCrop(anyLong(), any(Crop.class));
    }

    @Test
    public void testGetCropsByName() throws Exception {
        List<Crop> crops = Arrays.asList(new Crop(), new Crop());
        when(cropService.getcropbyname(anyString())).thenReturn(crops);

        mockMvc.perform(get("/api/crops/crop/Wheat"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));

        verify(cropService, times(1)).getcropbyname(anyString());
    }

    @Test
    public void testGetAllCrops() throws Exception {
        List<Crop> crops = Arrays.asList(new Crop(), new Crop());
        when(cropService.getAllCrops()).thenReturn(crops);

        mockMvc.perform(get("/api/crops"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));

        verify(cropService, times(1)).getAllCrops();
    }

    @Test
    public void testGetCropById() throws Exception {
        Crop crop = new Crop();
        crop.setCropId(1L);
        when(cropService.getCropById(anyLong())).thenReturn(crop);

        mockMvc.perform(get("/api/crops/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cropId").value(1));

        verify(cropService, times(1)).getCropById(anyLong());
    }

    @Test
    public void testUpdateCrop() throws Exception {
        Crop crop = new Crop();
        crop.setCropName("Wheat");
        when(cropService.updateCrop(anyLong(), any(Crop.class))).thenReturn(crop);

        mockMvc.perform(put("/api/crops/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"cropName\":\"Wheat\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cropName").value("Wheat"));

        verify(cropService, times(1)).updateCrop(anyLong(), any(Crop.class));
    }

    @Test
    public void testDeleteCrop() throws Exception {
        doNothing().when(cropService).deleteCrop(anyLong());

        mockMvc.perform(delete("/api/crops/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Crop deleted successfully with id: 1"));

        verify(cropService, times(1)).deleteCrop(anyLong());
    }
}
