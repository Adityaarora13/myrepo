package com.farmer.Farmer_service.Controller;

import com.farmer.Farmer_service.Service.Interface.CropService;
import com.farmer.Farmer_service.Service.Interface.FarmerCropService;
import com.farmer.Farmer_service.Service.Interface.FarmerService;
import com.farmer.Farmer_service.Model.Crop;
import com.farmer.Farmer_service.Model.Farmer;
import com.farmer.Farmer_service.Model.FarmerCropMapping;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class FarmerCropControllerTest {

    private MockMvc mockMvc;

    @Mock
    private FarmerCropService mappingService;

    @Mock
    private FarmerService farmerService;

    @Mock
    private CropService cropService;

    @InjectMocks
    private FarmerCropController farmerCropController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(farmerCropController).build();
    }



    @Test
    public void testGetAllCrops() throws Exception {
        List<Crop> crops = Arrays.asList(new Crop(), new Crop());
        when(cropService.getAllCrops()).thenReturn(crops);

        mockMvc.perform(get("/api/FarmerCrop/allcrops"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));

        verify(cropService, times(1)).getAllCrops();
    }

    @Test
    public void testGetMappingsByFarmer() throws Exception {
        List<FarmerCropMapping> mappings = Arrays.asList(new FarmerCropMapping(), new FarmerCropMapping());
        when(mappingService.getMappingsByFarmerId(anyLong())).thenReturn(mappings);

        mockMvc.perform(get("/api/FarmerCrop/farmer/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));

        verify(mappingService, times(1)).getMappingsByFarmerId(anyLong());
    }

    @Test
    public void testGetMappingsByCrop() throws Exception {
        List<FarmerCropMapping> mappings = Arrays.asList(new FarmerCropMapping(), new FarmerCropMapping());
        when(mappingService.getMappingsByCropId(anyLong())).thenReturn(mappings);

        mockMvc.perform(get("/api/FarmerCrop/crop/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));

        verify(mappingService, times(1)).getMappingsByCropId(anyLong());
    }

    @Test
    public void testGetAllMappings() throws Exception {
        List<FarmerCropMapping> mappings = Arrays.asList(new FarmerCropMapping(), new FarmerCropMapping());
        when(mappingService.getAllMappings()).thenReturn(mappings);

        mockMvc.perform(get("/api/FarmerCrop"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));

        verify(mappingService, times(1)).getAllMappings();
    }

    @Test
    public void testGetFarmerDetailsForCrop() throws Exception {
        FarmerCropMapping mapping = new FarmerCropMapping();
        mapping.setFarmerId(1L);
        List<FarmerCropMapping> mappings = Arrays.asList(mapping);
        Farmer farmer = new Farmer();
        when(mappingService.getMappingsByCropId(anyLong())).thenReturn(mappings);
        when(farmerService.getFarmerById(anyLong())).thenReturn(farmer);

        mockMvc.perform(get("/api/FarmerCrop/crop/1/farmer"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));

        verify(mappingService, times(1)).getMappingsByCropId(anyLong());
        verify(farmerService, times(1)).getFarmerById(anyLong());
    }

    @Test
    public void testGetCropDetailsForFarmer() throws Exception {
        FarmerCropMapping mapping = new FarmerCropMapping();
        mapping.setCropId(1L);
        List<FarmerCropMapping> mappings = Arrays.asList(mapping);
        Crop crop = new Crop();
        when(mappingService.getMappingsByFarmerId(anyLong())).thenReturn(mappings);
        when(cropService.getCropById(anyLong())).thenReturn(crop);

        mockMvc.perform(get("/api/FarmerCrop/farmer/1/crop"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));

        verify(mappingService, times(1)).getMappingsByFarmerId(anyLong());
        verify(cropService, times(1)).getCropById(anyLong());
    }
}
