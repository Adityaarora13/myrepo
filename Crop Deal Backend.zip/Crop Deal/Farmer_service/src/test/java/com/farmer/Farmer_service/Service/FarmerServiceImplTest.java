package com.farmer.Farmer_service.Service;

import com.farmer.Farmer_service.Service.Interface.FarmerCropService;
import com.farmer.Farmer_service.Model.Farmer;
import com.farmer.Farmer_service.Repository.FarmerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FarmerServiceImplTest {

    @Mock
    private FarmerRepository farmerRepository;

    @Mock
    private FarmerCropService farmerCropService;

    @InjectMocks
    private FarmerServiceImpl farmerService;

    private Farmer farmer;

    @BeforeEach
    void setUp() {
        farmer = new Farmer();

        farmer.setName("John Doe");
        farmer.setContactNumber("1234567890");
        farmer.setLocation("Farmville");
    }

    @Test
    void testSaveFarmer() {
        when(farmerRepository.save(any(Farmer.class))).thenReturn(farmer);
        Farmer savedFarmer = farmerService.saveFarmer(farmer);
        assertNotNull(savedFarmer);
        assertEquals(farmer.getName(), savedFarmer.getName());
    }

    @Test
    void testGetFarmerById() {
        when(farmerRepository.findById(1L)).thenReturn(Optional.of(farmer));
        Farmer foundFarmer = farmerService.getFarmerById(1L);
        assertNotNull(foundFarmer);
        assertEquals(farmer.getName(), foundFarmer.getName());
    }

    @Test
    void testGetAllFarmers() {
        List<Farmer> farmers = Arrays.asList(farmer);
        when(farmerRepository.findAll()).thenReturn(farmers);
        List<Farmer> allFarmers = farmerService.getAllFarmers();
        assertEquals(1, allFarmers.size());
    }

    @Test
    void testUpdateFarmer() {
        Farmer updatedDetails = new Farmer();
        updatedDetails.setName("Jane Doe");
        updatedDetails.setContactNumber("0987654321");
        updatedDetails.setLocation("New Farmville");

        when(farmerRepository.findById(1L)).thenReturn(Optional.of(farmer));
        when(farmerRepository.save(any(Farmer.class))).thenReturn(updatedDetails);

        Farmer updatedFarmer = farmerService.updateFarmer(1L, updatedDetails);
        assertNotNull(updatedFarmer);
        assertEquals(updatedDetails.getName(), updatedFarmer.getName());
    }

    @Test
    void testDeleteFarmer() {
        when(farmerRepository.findById(1L)).thenReturn(Optional.of(farmer));
        doNothing().when(farmerCropService).deleteMappingsByFarmerId(1L);
        doNothing().when(farmerRepository).delete(farmer);

        farmerService.deleteFarmer(1L);

        verify(farmerCropService, times(1)).deleteMappingsByFarmerId(1L);
        verify(farmerRepository, times(1)).delete(farmer);
    }
}
