package com.farmer.Farmer_service.Service;

import com.farmer.Farmer_service.Service.Interface.FarmerCropService;
import com.farmer.Farmer_service.Model.Crop;
import com.farmer.Farmer_service.Model.Farmer;
import com.farmer.Farmer_service.Repository.CropRepository;
import com.farmer.Farmer_service.Repository.FarmerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

public class CropServiceImplTest {

    @Mock
    private CropRepository cropRepository;

    @Mock
    private FarmerRepository farmerRepository;

    @Mock
    private FarmerCropService farmerCropService;

    @InjectMocks
    private CropServiceImpl cropService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddCrop() {
        Farmer farmer = new Farmer();
        Crop crop = new Crop();
        crop.setCropId(1L);

        when(farmerRepository.findById(anyLong())).thenReturn(Optional.of(farmer));
        when(cropRepository.save(any(Crop.class))).thenReturn(crop);

        Crop createdCrop = cropService.addCrop(1L, crop);

        assertNotNull(createdCrop);
        assertEquals(1L, createdCrop.getCropId());
        verify(farmerRepository, times(1)).findById(anyLong());
        verify(cropRepository, times(1)).save(any(Crop.class));
        verify(farmerCropService, times(1)).addMapping(anyLong(), anyLong());
    }

    @Test
    public void testGetAllCrops() {
        List<Crop> crops = Arrays.asList(new Crop(), new Crop());
        when(cropRepository.findAll()).thenReturn(crops);

        List<Crop> result = cropService.getAllCrops();

        assertEquals(2, result.size());
        verify(cropRepository, times(1)).findAll();
    }

    @Test
    public void testGetCropById() {
        Crop crop = new Crop();
        crop.setCropId(1L);
        when(cropRepository.findById(anyLong())).thenReturn(Optional.of(crop));

        Crop result = cropService.getCropById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getCropId());
        verify(cropRepository, times(1)).findById(anyLong());
    }

    @Test
    public void testUpdateCrop() {
        Crop crop = new Crop();
        Crop cropDetails = new Crop();
        cropDetails.setCropName("Wheat");
        cropDetails.setCropType("Grain");
        cropDetails.setPricePerKg(20.0);
        cropDetails.setQuantityAvailable(100.0);

        when(cropRepository.findById(anyLong())).thenReturn(Optional.of(crop));
        when(cropRepository.save(any(Crop.class))).thenReturn(crop);

        Crop updatedCrop = cropService.updateCrop(1L, cropDetails);

        assertNotNull(updatedCrop);
        assertEquals("Wheat", updatedCrop.getCropName());
        assertEquals("Grain", updatedCrop.getCropType());
        assertEquals(20.0, updatedCrop.getPricePerKg());
        assertEquals(100.0, updatedCrop.getQuantityAvailable());
        verify(cropRepository, times(1)).findById(anyLong());
        verify(cropRepository, times(1)).save(any(Crop.class));
    }

    @Test
    public void testDeleteCrop() {
        Crop crop = new Crop();
        when(cropRepository.findById(anyLong())).thenReturn(Optional.of(crop));
        doNothing().when(farmerCropService).deleteMappingsByCropId(anyLong());
        doNothing().when(cropRepository).delete(any(Crop.class));

        cropService.deleteCrop(1L);

        verify(cropRepository, times(1)).findById(anyLong());
        verify(farmerCropService, times(1)).deleteMappingsByCropId(anyLong());
        verify(cropRepository, times(1)).delete(any(Crop.class));
    }

    @Test
    public void testGetCropByName() {
        List<Crop> crops = Arrays.asList(new Crop(), new Crop());
        when(cropRepository.findByCropName(anyString())).thenReturn(crops);

        List<Crop> result = cropService.getcropbyname("Wheat");

        assertEquals(2, result.size());
        verify(cropRepository, times(1)).findByCropName(anyString());
    }
}
