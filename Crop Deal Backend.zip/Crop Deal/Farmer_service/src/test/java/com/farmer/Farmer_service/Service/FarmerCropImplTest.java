package com.farmer.Farmer_service.Service;

import com.farmer.Farmer_service.Model.FarmerCropMapping;
import com.farmer.Farmer_service.Repository.FarmerCropMappingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

public class FarmerCropImplTest {

    @Mock
    private FarmerCropMappingRepository mappingRepository;

    @InjectMocks
    private FarmerCropImpl farmerCropService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddMapping() {
        FarmerCropMapping mapping = new FarmerCropMapping();
        mapping.setFarmerId(1L);
        mapping.setCropId(1L);

        when(mappingRepository.save(any(FarmerCropMapping.class))).thenReturn(mapping);

        FarmerCropMapping createdMapping = farmerCropService.addMapping(1L, 1L);

        assertNotNull(createdMapping);
        assertEquals(1L, createdMapping.getFarmerId());
        assertEquals(1L, createdMapping.getCropId());
        verify(mappingRepository, times(1)).save(any(FarmerCropMapping.class));
    }

    @Test
    public void testGetMappingsByFarmerId() {
        List<FarmerCropMapping> mappings = Arrays.asList(new FarmerCropMapping(), new FarmerCropMapping());
        when(mappingRepository.findByFarmerId(anyLong())).thenReturn(mappings);

        List<FarmerCropMapping> result = farmerCropService.getMappingsByFarmerId(1L);

        assertEquals(2, result.size());
        verify(mappingRepository, times(1)).findByFarmerId(anyLong());
    }

    @Test
    public void testGetMappingsByCropId() {
        List<FarmerCropMapping> mappings = Arrays.asList(new FarmerCropMapping(), new FarmerCropMapping());
        when(mappingRepository.findByCropId(anyLong())).thenReturn(mappings);

        List<FarmerCropMapping> result = farmerCropService.getMappingsByCropId(1L);

        assertEquals(2, result.size());
        verify(mappingRepository, times(1)).findByCropId(anyLong());
    }

    @Test
    public void testGetAllMappings() {
        List<FarmerCropMapping> mappings = Arrays.asList(new FarmerCropMapping(), new FarmerCropMapping());
        when(mappingRepository.findAll()).thenReturn(mappings);

        List<FarmerCropMapping> result = farmerCropService.getAllMappings();

        assertEquals(2, result.size());
        verify(mappingRepository, times(1)).findAll();
    }

    @Test
    public void testDeleteMappingsByFarmerId() {
        doNothing().when(mappingRepository).deleteByFarmerId(anyLong());

        farmerCropService.deleteMappingsByFarmerId(1L);

        verify(mappingRepository, times(1)).deleteByFarmerId(anyLong());
    }

    @Test
    public void testDeleteMappingsByCropId() {
        doNothing().when(mappingRepository).deleteByCropId(anyLong());

        farmerCropService.deleteMappingsByCropId(1L);

        verify(mappingRepository, times(1)).deleteByCropId(anyLong());
    }
}
