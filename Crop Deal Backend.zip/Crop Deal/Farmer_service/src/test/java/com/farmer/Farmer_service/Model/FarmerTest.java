package com.farmer.Farmer_service.Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class FarmerTest {

    private Farmer farmer;
    private Crop crop;

    @BeforeEach
    void setUp() {
        farmer = new Farmer();
        farmer.setFarmerId(1L);
        farmer.setName("John Doe");
        farmer.setContactNumber("1234567890");
        farmer.setLocation("Farmville");

        crop = new Crop();
        crop.setCropId(1L);
        crop.setCropName("Wheat");
        crop.setFarmer(farmer);

        List<Crop> crops = new ArrayList<>();
        crops.add(crop);
        farmer.setCrops(crops);
    }

    @Test
    void testFarmerFields() {
        assertEquals(1L, farmer.getFarmerId());
        assertEquals("John Doe", farmer.getName());
        assertEquals("1234567890", farmer.getContactNumber());
        assertEquals("Farmville", farmer.getLocation());
    }

    @Test
    void testFarmerCrops() {
        List<Crop> crops = farmer.getCrops();
        assertNotNull(crops);
        assertEquals(1, crops.size());
        assertEquals("Wheat", crops.get(0).getCropName());
        assertEquals(farmer, crops.get(0).getFarmer());
    }

    @Test
    void testAddCrop() {
        Crop newCrop = new Crop();
        newCrop.setCropId(2L);
        newCrop.setCropName("Corn");
        newCrop.setFarmer(farmer);

        farmer.getCrops().add(newCrop);

        assertEquals(2, farmer.getCrops().size());
        assertEquals("Corn", farmer.getCrops().get(1).getCropName());
    }

    @Test
    void testRemoveCrop() {
        farmer.getCrops().remove(crop);

        assertEquals(0, farmer.getCrops().size());
    }
}
