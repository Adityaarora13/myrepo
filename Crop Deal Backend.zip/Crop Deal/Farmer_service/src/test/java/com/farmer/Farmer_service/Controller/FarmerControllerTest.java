package com.farmer.Farmer_service.Controller;

import com.farmer.Farmer_service.Service.Interface.CropService;
import com.farmer.Farmer_service.Model.Crop;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@WebMvcTest(CropController.class)
class FarmerControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CropService cropService;

    @Autowired
    private ObjectMapper objectMapper; // To convert Java objects to JSON

    private Crop crop;

    @BeforeEach
    void setUp() {
        crop = new Crop();
        crop.setCropId(1L);
        crop.setCropName("Wheat");
        crop.setCropType("Grain");
        crop.setPricePerKg(25.5);
        crop.setQuantityAvailable(100.0);
    }

    @Test
    void testAddCrop() throws Exception {
        Mockito.when(cropService.addCrop(eq(1L), any(Crop.class))).thenReturn(crop);

        mockMvc.perform(post("/api/crops/farmer/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(crop)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cropName").value("Wheat"));
    }

    @Test
    void testGetAllCrops() throws Exception {
        List<Crop> crops = Arrays.asList(crop);
        Mockito.when(cropService.getAllCrops()).thenReturn(crops);

        mockMvc.perform(get("/api/crops"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].cropName").value("Wheat"));
    }

    @Test
    void testGetCropById() throws Exception {
        Mockito.when(cropService.getCropById(1L)).thenReturn(crop);

        mockMvc.perform(get("/api/crops/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cropName").value("Wheat"));
    }

    @Test
    void testUpdateCrop() throws Exception {
        crop.setCropName("Updated Wheat");
        Mockito.when(cropService.updateCrop(eq(1L), any(Crop.class))).thenReturn(crop);

        mockMvc.perform(put("/api/crops/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(crop)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cropName").value("Updated Wheat"));
    }

    @Test
    void testDeleteCrop() throws Exception {
        Mockito.doNothing().when(cropService).deleteCrop(1L);

        mockMvc.perform(delete("/api/crops/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Crop deleted successfully with id: 1"));
    }
}