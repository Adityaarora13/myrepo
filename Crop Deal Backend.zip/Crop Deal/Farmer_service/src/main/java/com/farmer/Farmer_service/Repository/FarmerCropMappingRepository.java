package com.farmer.Farmer_service.Repository;

import com.farmer.Farmer_service.Model.FarmerCropMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FarmerCropMappingRepository extends JpaRepository<FarmerCropMapping , Long> {

    List<FarmerCropMapping> findByFarmerId(Long farmerId);
    List<FarmerCropMapping> findByCropId(Long cropId);

    void deleteByFarmerId(Long farmerId);

    void deleteByCropId(Long cropId);
}
