package com.farmer.Farmer_service.Service;

import com.farmer.Farmer_service.Exception.DuplicateException;
import com.farmer.Farmer_service.Exception.EntryNotFound;
import com.farmer.Farmer_service.Service.Interface.CropService;
import com.farmer.Farmer_service.Service.Interface.FarmerCropService;
import com.farmer.Farmer_service.Model.Crop;
import com.farmer.Farmer_service.Model.Farmer;
import com.farmer.Farmer_service.Repository.CropRepository;
import com.farmer.Farmer_service.Repository.FarmerRepository;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CropServiceImpl implements CropService {

    private static final Logger log = LoggerFactory.getLogger(CropServiceImpl.class);

    private final CropRepository cropRepository;
    private final FarmerRepository farmerRepository;
    private final FarmerCropService farmerCropService;

    @Autowired
    public CropServiceImpl(CropRepository cropRepository, FarmerRepository farmerRepository, FarmerCropService farmerCropService) {
        this.cropRepository = cropRepository;
        this.farmerRepository = farmerRepository;
        this.farmerCropService = farmerCropService;
    }

    @Override
    public Crop addCrop(Long farmerId, Crop crop) {
        log.info("Attempting to add crop for farmerId: {}", farmerId);

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> {
                    log.error("Farmer not found with id: {}", farmerId);
                    return new EntryNotFound("Farmer not found with id: " + farmerId);
                });

        crop.setFarmer(farmer);
        crop.setFarmer_id_display(farmerId);
        String cropName = crop.getCropName();

        List<Crop> crops = farmer.getCrops();
        for (Crop c : crops) {
            if (c.getCropName().equals(cropName)) {
                log.warn("Duplicate crop entry: {}", cropName);
                throw new DuplicateException("Duplicate Entry for the crop " + cropName);
            }
        }

        Crop createdCrop = cropRepository.save(crop);
        farmerCropService.addMapping(farmerId, createdCrop.getCropId());

        log.info("Successfully added crop: {} for farmerId: {}", cropName, farmerId);
        return createdCrop;
    }

    @Override
    public List<Crop> getAllCrops() {
        log.info("Fetching all crops from database");

        List<Crop> crops = cropRepository.findAll();
        if (crops.isEmpty()) {
            log.warn("No crops available in the system");
            throw new EntryNotFound("No crops available in the system.");
        }

        return crops;
    }

    @Override
    public Crop getCropById(Long id) {
        log.info("Fetching crop by id: {}", id);

        return cropRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Crop not found with id: {}", id);
                    return new EntryNotFound("Crop not found with id: " + id);
                });
    }

    @Override
    public Crop updateCrop(Long id, Crop cropDetails) {
        log.info("Updating crop with id: {}", id);

        Crop crop = cropRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Crop not found for update with id: {}", id);
                    return new EntryNotFound("Crop not found with id: " + id);
                });

        crop.setCropName(cropDetails.getCropName());
        crop.setCropType(cropDetails.getCropType());
        crop.setPricePerKg(cropDetails.getPricePerKg());
        crop.setQuantityAvailable(cropDetails.getQuantityAvailable());

        Crop updated = cropRepository.save(crop);
        log.info("Crop updated successfully with id: {}", id);
        return updated;
    }

    @Override
    @Transactional
    public void deleteCrop(Long id) {
        log.info("Attempting to delete crop with id: {}", id);

        Crop crop = cropRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Crop not found for deletion with id: {}", id);
                    return new EntryNotFound("Crop not found with id: " + id);
                });

        farmerCropService.deleteMappingsByCropId(id);
        cropRepository.delete(crop);

        log.info("Successfully deleted crop with id: {}", id);
    }

    @Override
    public List<Crop> getcropbyname(String cropName) {
        log.info("Fetching crops by name: {}", cropName);

        List<Crop> crops = cropRepository.findByCropName(cropName);
        if (crops.isEmpty()) {
            log.warn("No crops found with name: {}", cropName);
            throw new EntryNotFound("No crops found with name: " + cropName);
        }

        return crops;
    }
}
