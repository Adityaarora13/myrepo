package com.farmer.Farmer_service.Service.Interface;
import com.farmer.Farmer_service.Model.Crop;
import com.farmer.Farmer_service.Model.Farmer;

import java.util.List;

public interface FarmerService {

        Farmer saveFarmer(Farmer farmer);
        Farmer getFarmerById(Long id);
        List<Farmer> getAllFarmers();
        Farmer updateFarmer(Long id, Farmer farmer);
        void deleteFarmer(Long id);
        void deleteFarmerByEmail(String email);

        Farmer getFarmerByEmail(String email);

        List<Crop> getAllCropsByFarmerId(Long farmerId);
}
