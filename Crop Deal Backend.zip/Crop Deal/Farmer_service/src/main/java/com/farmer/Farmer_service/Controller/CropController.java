package com.farmer.Farmer_service.Controller;

import com.farmer.Farmer_service.Service.Interface.CropService;
import com.farmer.Farmer_service.Model.Crop;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crops")
public class CropController {

    private static final Logger log = LoggerFactory.getLogger(CropController.class);

    private final CropService cropService;

    @Autowired
    public CropController(CropService service) {
        this.cropService = service;
    }

    // Add Crop to a Farmer
    @PostMapping("/farmer/{farmerId}")
    public ResponseEntity<Crop> addCrop(@PathVariable Long farmerId, @RequestBody Crop crop) {
        log.info("Request to add crop for farmer with ID: {}", farmerId);
        Crop savedCrop = cropService.addCrop(farmerId, crop);
        log.debug("Crop saved: {}", savedCrop);
        return ResponseEntity.ok(savedCrop);
    }

    // Get all the crops based on crop name
    @GetMapping("/crop/{cropName}")
    public ResponseEntity<List<Crop>> getCropsByName(@PathVariable String cropName) {
        log.info("Fetching crops with name: {}", cropName);
        List<Crop> crops = cropService.getcropbyname(cropName);
        log.debug("Crops found: {}", crops.size());
        return ResponseEntity.ok(crops);
    }

    // Get All Crops
    @GetMapping
    public ResponseEntity<List<Crop>> getAllCrops() {
        log.info("Fetching all crops");
        List<Crop> crops = cropService.getAllCrops();
        log.debug("Total crops found: {}", crops.size());
        return ResponseEntity.ok(crops);
    }

    // Get Crop by ID
    @GetMapping("/{id}")
    public ResponseEntity<Crop> getCropById(@PathVariable Long id) {
        log.info("Fetching crop with ID: {}", id);
        Crop crop = cropService.getCropById(id);
        log.debug("Crop found: {}", crop);
        return ResponseEntity.ok(crop);
    }

    // Update Crop
    @PutMapping("/{id}")
    public ResponseEntity<Crop> updateCrop(@PathVariable Long id, @RequestBody Crop cropDetails) {
        log.info("Updating crop with ID: {}", id);
        Crop updatedCrop = cropService.updateCrop(id, cropDetails);
        log.debug("Crop updated: {}", updatedCrop);
        return ResponseEntity.ok(updatedCrop);
    }

    // Delete Crop
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCrop(@PathVariable Long id) {
        log.info("Deleting crop with ID: {}", id);
        cropService.getCropById(id); // Ensure it exists
        cropService.deleteCrop(id);
        log.info("Crop deleted successfully with ID: {}", id);
        return ResponseEntity.ok("Crop deleted successfully with id: " + id);
    }
}
