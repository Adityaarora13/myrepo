package com.farmer.Farmer_service.Service;

import com.farmer.Farmer_service.Service.Interface.FarmerCropService;
import com.farmer.Farmer_service.Model.FarmerCropMapping;
import com.farmer.Farmer_service.Repository.FarmerCropMappingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FarmerCropImpl implements FarmerCropService {

    private static final Logger log = LoggerFactory.getLogger(FarmerCropImpl.class);

    @Autowired
    private FarmerCropMappingRepository mappingRepository;

    @Override
    public FarmerCropMapping addMapping(Long farmerId, Long cropId) {
        log.info("Adding mapping for Farmer ID: {} and Crop ID: {}", farmerId, cropId);

        FarmerCropMapping mapping = new FarmerCropMapping();
        mapping.setFarmerId(farmerId);
        mapping.setCropId(cropId);

        FarmerCropMapping savedMapping = mappingRepository.save(mapping);
        log.info("Successfully added mapping with ID: {}");

        return savedMapping;
    }

    @Override
    public List<FarmerCropMapping> getMappingsByFarmerId(Long farmerId) {
        log.info("Fetching mappings for Farmer ID: {}", farmerId);
        return mappingRepository.findByFarmerId(farmerId);
    }

    @Override
    public List<FarmerCropMapping> getMappingsByCropId(Long cropId) {
        log.info("Fetching mappings for Crop ID: {}", cropId);
        return mappingRepository.findByCropId(cropId);
    }

    @Override
    public List<FarmerCropMapping> getAllMappings() {
        log.info("Fetching all farmer-crop mappings");
        return mappingRepository.findAll();
    }

    @Override
    public void deleteMappingsByFarmerId(Long farmerId) {
        log.info("Deleting mappings for Farmer ID: {}", farmerId);
        mappingRepository.deleteByFarmerId(farmerId);
        log.info("Deleted mappings for Farmer ID: {}", farmerId);
    }

    @Override
    public void deleteMappingsByCropId(Long cropId) {
        log.info("Deleting mappings for Crop ID: {}", cropId);
        mappingRepository.deleteByCropId(cropId);
        log.info("Deleted mappings for Crop ID: {}", cropId);
    }
}
