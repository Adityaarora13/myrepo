package com.farmer.Farmer_service.Service.Interface;

import com.farmer.Farmer_service.Model.FarmerCropMapping;

import java.util.List;

public interface FarmerCropService {

    //get all the crops
    public FarmerCropMapping addMapping(Long farmerId, Long cropId);
    public List<FarmerCropMapping> getMappingsByFarmerId(Long farmerId);

    public List<FarmerCropMapping> getMappingsByCropId(Long cropId);

    public List<FarmerCropMapping> getAllMappings ();

    //delete the farmer delete the mapping
    public void deleteMappingsByFarmerId(Long farmerId);

    public void deleteMappingsByCropId(Long cropId);

}
