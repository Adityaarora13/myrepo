package com.farmer.Farmer_service.Controller;

import com.farmer.Farmer_service.Service.Interface.FarmerService;
import com.farmer.Farmer_service.Model.Crop;
import com.farmer.Farmer_service.Model.Farmer;
import com.farmer.Farmer_service.Repository.CropRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/farmer")
public class FarmerController {

    private static final Logger log = LoggerFactory.getLogger(FarmerController.class);

    @Autowired
    private FarmerService farmerService;

    @Autowired
    private CropRepository cropRepository;

    // Save Farmer
    @PostMapping
    public ResponseEntity<Farmer> saveFarmer(@RequestBody Farmer farmer) {
        log.info("Saving new farmer: {}", farmer);
        Farmer savedFarmer = farmerService.saveFarmer(farmer);
        log.debug("Farmer saved successfully: {}", savedFarmer);
        return ResponseEntity.ok(savedFarmer);
    }

    // Get Farmer by ID
    @GetMapping("/{id}")
    public ResponseEntity<Farmer> getFarmerById(@PathVariable Long id) {
        log.info("Fetching farmer with ID: {}", id);
        Farmer farmer = farmerService.getFarmerById(id);
        log.debug("Farmer found: {}", farmer);
        return ResponseEntity.ok(farmer);
    }

    // Get Farmer by Email
    @GetMapping("/get/{email}")
    public ResponseEntity<Farmer> getFarmerByEmail(@PathVariable String email) {
        log.info("Fetching farmer with email: {}", email);
        Farmer farmer = farmerService.getFarmerByEmail(email);
        log.debug("Farmer found: {}", farmer);
        return ResponseEntity.ok(farmer);
    }

    // Get all the crops with farmer ID
    @GetMapping("/crops/{farmerId}")
    public ResponseEntity<List<Crop>> getAllCropByFarmerId(@PathVariable Long farmerId) {
        log.info("Fetching crops for farmer ID: {}", farmerId);
        List<Crop> crops = farmerService.getAllCropsByFarmerId(farmerId);
        log.debug("Number of crops found: {}", crops.size());
        return ResponseEntity.ok(crops);
    }

    // Get All Farmers
    @GetMapping
    public ResponseEntity<List<Farmer>> getAllFarmers() {
        log.info("Fetching all farmers");
        List<Farmer> farmers = farmerService.getAllFarmers();
        log.debug("Total farmers found: {}", farmers.size());
        return ResponseEntity.ok(farmers);
    }

    // Update Farmer
    @PutMapping("/{id}")
    public ResponseEntity<Farmer> updateFarmer(@PathVariable Long id, @RequestBody Farmer farmer) {
        log.info("Updating farmer with ID: {}", id);
        Farmer updatedFarmer = farmerService.updateFarmer(id, farmer);
        log.debug("Farmer updated successfully: {}", updatedFarmer);
        return ResponseEntity.ok(updatedFarmer);
    }

    // Delete Farmer
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFarmer(@PathVariable Long id) {
        log.info("Deleting farmer with ID: {}", id);
        farmerService.deleteFarmer(id);
        log.info("Farmer with ID: {} deleted successfully", id);
        return ResponseEntity.ok("Farmer with id " + id + " deleted successfully!");
    }

    // Delete Farmer by Email
    @DeleteMapping("/delete/{email}")
    public ResponseEntity<String> deleteEmail(@PathVariable String email) {
        log.info("Deleting farmer with email: {}", email);
        farmerService.deleteFarmerByEmail(email);
        log.info("Farmer with email: {} deleted successfully", email);
        return new ResponseEntity<>("Farmer with email " + email + " is deleted", HttpStatus.OK);
    }
}
