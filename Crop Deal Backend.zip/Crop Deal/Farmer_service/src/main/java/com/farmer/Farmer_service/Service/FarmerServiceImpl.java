package com.farmer.Farmer_service.Service;

import com.farmer.Farmer_service.Exception.EntryNotFound;
import com.farmer.Farmer_service.Service.Interface.FarmerCropService;
import com.farmer.Farmer_service.Service.Interface.FarmerService;
import com.farmer.Farmer_service.Model.Crop;
import com.farmer.Farmer_service.Model.Farmer;
import com.farmer.Farmer_service.Repository.FarmerRepository;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FarmerServiceImpl implements FarmerService {

    private static final Logger log = LoggerFactory.getLogger(FarmerServiceImpl.class);

    @Autowired
    private FarmerRepository farmerRepository;

    @Autowired
    private FarmerCropService farmerCropService;

    // ──────────────────────────────────────────
    // Add Farmer
    @Override
    public Farmer saveFarmer(Farmer farmer) {
        log.info("Saving new farmer: email={}", farmer.getEmail());
        Farmer saved = farmerRepository.save(farmer);
        log.debug("Farmer saved → {}");
        return saved;
    }

    // Find Farmer By farmerId
    @Override
    public Farmer getFarmerById(Long id) {
        log.info("Fetching farmer with id={}", id);
        return farmerRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Farmer not found with id={}", id);
                    return new EntryNotFound("Farmer not found with id: " + id);
                });
    }

    // Find All Farmers
    @Override
    public List<Farmer> getAllFarmers() {
        log.info("Fetching all farmers");
        List<Farmer> farmers = farmerRepository.findAll();
        if (farmers.isEmpty()) {
            log.warn("No farmers available in the system");
            throw new EntryNotFound("No farmers available in the system.");
        }
        log.debug("Total farmers found: {}", farmers.size());
        return farmers;
    }

    // Update Farmer By FarmerId
    @Override
    public Farmer updateFarmer(Long id, Farmer farmerDetails) {
        log.info("Updating farmer id={}", id);
        Farmer farmer = getFarmerById(id);

        farmer.setContactNumber(farmerDetails.getContactNumber());
        farmer.setLocation(farmerDetails.getLocation());

        Farmer updated = farmerRepository.save(farmer);
        log.debug("Farmer updated: {}");
        return updated;
    }

    // Delete Farmer
    @Override
    @Transactional
    public void deleteFarmer(Long id) {
        log.info("Deleting farmer id={}", id);
        Farmer farmer = getFarmerById(id);  // throws if not found
        farmerCropService.deleteMappingsByFarmerId(id);
        farmerRepository.delete(farmer);
        log.info("Farmer id={} deleted successfully", id);
    }

    // Delete Farmer By Email Id
    @Override
    @Transactional
    public void deleteFarmerByEmail(String email) {
        log.info("Deleting farmer by email={}", email);
        farmerRepository.deleteByEmail(email);
        log.info("Farmer with email={} deleted", email);
    }

    // Get Farmer By Email Id
    @Override
    public Farmer getFarmerByEmail(String email) {
        log.info("Fetching farmer by email={}", email);
        Farmer farmer = farmerRepository.findByEmail(email);
        if (farmer == null) {
            log.warn("Farmer not found with email={}", email);
            throw new EntryNotFound("Farmer not found with email: " + email);
        }
        return farmer;
    }

    // Get All the Crops of Farmer By Farmer Id
    @Override
    public List<Crop> getAllCropsByFarmerId(Long farmerId) {
        log.info("Fetching crops for farmer id={}", farmerId);
        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> {
                    log.error("Farmer not found with id={}", farmerId);
                    return new EntryNotFound("Farmer not found with id: " + farmerId);
                });

        List<Crop> crops = farmer.getCrops();
        if (crops == null || crops.isEmpty()) {
            log.warn("No crops found for farmer id={}", farmerId);
            throw new EntryNotFound("No crops found for farmer with id: " + farmerId);
        }

        log.debug("Found {} crops for farmer id={}", crops.size(), farmerId);
        return crops;
    }
}
