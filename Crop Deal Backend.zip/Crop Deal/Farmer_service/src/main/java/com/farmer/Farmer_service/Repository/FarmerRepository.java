package com.farmer.Farmer_service.Repository;

import com.farmer.Farmer_service.Model.Farmer;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FarmerRepository extends JpaRepository<Farmer, Long> {
    @Transactional
    void deleteByEmail(String email);

    Farmer findByEmail(String email);
}
