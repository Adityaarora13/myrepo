package com.farmer.Farmer_service.Exception;

public class EntryNotFound extends RuntimeException{
    public EntryNotFound(String s){
        super(s);
    }
}
