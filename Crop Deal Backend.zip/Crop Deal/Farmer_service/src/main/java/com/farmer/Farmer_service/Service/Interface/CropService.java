package com.farmer.Farmer_service.Service.Interface;

import com.farmer.Farmer_service.Model.Crop;

import java.util.List;

public interface CropService {
    Crop addCrop(Long farmerId, Crop crop);
    //boolean addCrop(Long farmerId,Crop crop);
    List<Crop> getAllCrops();
    Crop getCropById(Long id);
    Crop updateCrop(Long id, Crop cropDetails);
    void deleteCrop(Long id);
    List<Crop> getcropbyname(String Cropname);


}
