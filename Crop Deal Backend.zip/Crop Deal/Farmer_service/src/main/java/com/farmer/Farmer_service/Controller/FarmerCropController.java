package com.farmer.Farmer_service.Controller;

import com.farmer.Farmer_service.Service.Interface.CropService;
import com.farmer.Farmer_service.Service.Interface.FarmerCropService;
import com.farmer.Farmer_service.Service.Interface.FarmerService;
import com.farmer.Farmer_service.Model.Crop;
import com.farmer.Farmer_service.Model.FarmerCropMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/FarmerCrop")
public class FarmerCropController {

    private static final Logger log = LoggerFactory.getLogger(FarmerCropController.class);

    @Autowired
    private FarmerCropService mappingService;

    @Autowired
    private FarmerService farmerService;

    @Autowired
    private CropService cropService;

    // ───────────────────────────────────────────────────────────────

    /** Create a farmer–crop mapping */
    @PostMapping
    public FarmerCropMapping createMapping(@RequestParam Long farmerId,
                                           @RequestParam Long cropId) {
        log.info("Creating mapping: farmerId={}, cropId={}", farmerId, cropId);
        FarmerCropMapping mapping = mappingService.addMapping(farmerId, cropId);
        log.debug("Mapping created -> {}", mapping);
        return mapping;
    }

    /** Show every crop (for dealers, etc.) */
    @GetMapping("/allcrops")
    public List<Crop> getAllCrops() {
        log.info("Fetching all crops");
        List<Crop> crops = cropService.getAllCrops();
        log.debug("Total crops found: {}", crops.size());
        return crops;
    }

    /** All mappings for a given farmer */
    @GetMapping("/farmer/{farmerId}")
    public List<FarmerCropMapping> getMappingsByFarmer(@PathVariable Long farmerId) {
        log.info("Fetching mappings for farmerId={}", farmerId);
        List<FarmerCropMapping> mappings = mappingService.getMappingsByFarmerId(farmerId);
        log.debug("Mappings found: {}", mappings.size());
        return mappings;
    }

    /** All mappings for a given crop */
    @GetMapping("/crop/{cropId}")
    public List<FarmerCropMapping> getMappingsByCrop(@PathVariable Long cropId) {
        log.info("Fetching mappings for cropId={}", cropId);
        List<FarmerCropMapping> mappings = mappingService.getMappingsByCropId(cropId);
        log.debug("Mappings found: {}", mappings.size());
        return mappings;
    }

    /** All farmer–crop mappings */
    @GetMapping
    public List<FarmerCropMapping> getAllMappings() {
        log.info("Fetching ALL farmer-crop mappings");
        List<FarmerCropMapping> mappings = mappingService.getAllMappings();
        log.debug("Total mappings found: {}", mappings.size());
        return mappings;
    }

    /** Farmer details for a specific crop */
    @GetMapping("/crop/{cropId}/farmer")
    public Object getFarmerDetailsForCrop(@PathVariable Long cropId) {
        log.info("Fetching farmer details for cropId={}", cropId);
        List<FarmerCropMapping> mappings = mappingService.getMappingsByCropId(cropId);
        return mappings.stream()
                .map(m -> {
                    log.debug(" → farmerId={}", m.getFarmerId());
                    return farmerService.getFarmerById(m.getFarmerId());
                })
                .collect(Collectors.toList());
    }

    /** Crop details for a specific farmer */
    @GetMapping("/farmer/{farmerId}/crop")
    public Object getCropDetailsForFarmer(@PathVariable Long farmerId) {
        log.info("Fetching crop details for farmerId={}", farmerId);
        List<FarmerCropMapping> mappings = mappingService.getMappingsByFarmerId(farmerId);
        return mappings.stream()
                .map(m -> {
                    log.debug(" → cropId={}", m.getCropId());
                    return cropService.getCropById(m.getCropId());
                })
                .collect(Collectors.toList());
    }
}
