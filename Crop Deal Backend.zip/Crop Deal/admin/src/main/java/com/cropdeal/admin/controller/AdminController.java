package com.cropdeal.admin.controller;

import com.cropdeal.admin.dto.dealerDto;
import com.cropdeal.admin.dto.farmerDto;
import com.cropdeal.admin.service.AdminServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminServiceImpl adminServiceImp;

    @GetMapping("/welcome")
    public String welcome() {
        log.info("Accessed /welcome endpoint");
        return "Welcome to Admin Portal";
    }

    // Find All Farmers
    @GetMapping("/farmers")
    public ResponseEntity<List<farmerDto>> getAllFarmers() {
        log.info("Fetching all farmers");
        try {
            List<farmerDto> farmers = adminServiceImp.getAllFarmers();
            log.debug("Found {} farmers", farmers.size());
            return new ResponseEntity<>(farmers, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error fetching farmers: {}", e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete Farmer By emailId
    @DeleteMapping("/farmers/delete/{email}")
    public ResponseEntity<String> deleteFarmer(@PathVariable String email) {
        log.info("Request to delete farmer with email: {}", email);
        String result = adminServiceImp.deleteByFarmerEmail(email);
        log.debug("Deletion result: {}", result);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    // Find All Dealers
    @GetMapping("/dealers")
    public ResponseEntity<List<dealerDto>> getAllDealers() {
        log.info("Fetching all dealers");
        List<dealerDto> dealers = adminServiceImp.getAllDealers();
        log.debug("Found {} dealers", dealers.size());
        return new ResponseEntity<>(dealers, HttpStatus.OK);
    }

    // Delete dealer by dealer Id
    @DeleteMapping("/dealer/delete/{email}")
    public ResponseEntity<String> deleteDealer(@PathVariable String email) {
        log.info("Request to delete dealer with email: {}", email);
        adminServiceImp.deleteByDealerEmail(email);
        log.debug("Dealer with email {} deleted", email);
        return new ResponseEntity<>("Dealer Deleted Successfully", HttpStatus.OK);
    }

    // Find All Users
    @GetMapping("/allusers")
    public ResponseEntity<Object> allusers() {
        log.info("Fetching all users");
        Object users = adminServiceImp.getalluser();
        log.debug("All users data: {}", users);
        return new ResponseEntity<>(users, HttpStatus.OK);
    }
}
