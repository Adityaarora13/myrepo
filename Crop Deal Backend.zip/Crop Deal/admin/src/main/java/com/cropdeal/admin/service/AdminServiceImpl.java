package com.cropdeal.admin.service;

import com.cropdeal.admin.Exception.ResourceNotFound;
import com.cropdeal.admin.dto.dealerDto;
import com.cropdeal.admin.dto.farmerDto;
import com.cropdeal.admin.feign.FarmerServiceClient;
import com.cropdeal.admin.feign.DealerServiceClient;
import com.cropdeal.admin.feign.UserClient;
import com.cropdeal.admin.repository.AdminRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    public AdminRepository adminRepository;

    @Autowired
    public FarmerServiceClient farmerServiceClient;

    @Autowired
    public DealerServiceClient dealerServiceClient;

    @Autowired
    UserClient userClient;

    // find All Farmers from Farmer Microservice By Feign Client
    @Override
    public List<farmerDto> getAllFarmers() {
        log.info("Fetching all farmers via FarmerServiceClient");
        List<farmerDto> farmers = farmerServiceClient.getAllFarmers();

        if (farmers == null || farmers.isEmpty()) {
            log.warn("No farmers found");
            throw new ResourceNotFound("No farmers found");
        }
        log.debug("Fetched {} farmers", farmers.size());
        return farmers;
    }

    // Find All Dealers from Dealer microservice By feign client
    @Override
    public List<dealerDto> getAllDealers() {
        log.info("Fetching all dealers via DealerServiceClient");
        List<dealerDto> dealers = dealerServiceClient.getAllDealers();
        if (dealers == null || dealers.isEmpty()) {
            log.warn("No dealers found");
            throw new ResourceNotFound("No dealers found");
        }
        log.debug("Fetched {} dealers", dealers.size());
        return dealers;
    }

    // Delete Farmer By Email from both user database and farmer database
    @Override
    @Transactional
    public String deleteByFarmerEmail(String email) {
        log.info("Deleting farmer and user with email: {}", email);
        farmerServiceClient.deleteFarmerByEmail(email);
        userClient.DeleteFarmerEmail(email);
        log.debug("Deleted farmer and user with email: {}", email);
        return "User deleted SuccessFully!!";
    }

    // Delete Dealer By Email from both user database and dealer database
    @Override
    public String deleteByDealerEmail(String email) {
        log.info("Deleting dealer and user with email: {}", email);
        dealerServiceClient.deleteByEmail(email);
        userClient.DeleteDealerEmail(email);
        log.debug("Deleted dealer and user with email: {}", email);
        return "User deleted SuccessFully!!";
    }

    @Override
    public Optional<Object> getalluserById(Long id) {
        log.info("Fetching user by ID: {}", id);
        return userClient.getUserById(id);
    }

    @Override
    public List<Object> getalluser() {
        log.info("Fetching all users via UserClient");
        List<Object> users = userClient.Getalluser();
        log.debug("Fetched {} users", users.size());
        return users;
    }
}
