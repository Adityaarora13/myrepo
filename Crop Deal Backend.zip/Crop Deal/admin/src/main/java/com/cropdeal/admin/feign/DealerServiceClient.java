package com.cropdeal.admin.feign;


import com.cropdeal.admin.dto.dealerDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient(name = "DEALERSERVICE") // service name registered in Eureka
public interface DealerServiceClient {

    @GetMapping("/api/dealer/all")
    List<dealerDto> getAllDealers();

    @DeleteMapping("/api/dealer/delete/email/{email}")
    void deleteByEmail(@PathVariable("email") String email);


}
