package com.cropdeal.admin.service;

import com.cropdeal.admin.dto.dealerDto;
import com.cropdeal.admin.dto.farmerDto;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

public interface AdminService {

    // New methods
    List<farmerDto> getAllFarmers();
    List<dealerDto> getAllDealers();
    String deleteByFarmerEmail(String email);
    String deleteByDealerEmail(String email);
    Optional<Object> getalluserById(Long id);
    List<Object> getalluser();
}
