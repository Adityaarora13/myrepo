package com.cropdeal.admin.dto;

import lombok.Data;

@Data
public class dealerDto {
    private Long dealerId;
    private String name;
    private String email;



}
