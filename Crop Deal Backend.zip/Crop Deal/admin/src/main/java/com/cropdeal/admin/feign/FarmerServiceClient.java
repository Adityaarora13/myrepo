package com.cropdeal.admin.feign;

import com.cropdeal.admin.dto.farmerDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient(name = "FARMERSERVICE") // service name registered in Eureka
public interface FarmerServiceClient {

    @GetMapping("/api/farmer")
    List<farmerDto> getAllFarmers();

//    @DeleteMapping("/api/farmer/{id}")
//    String deleteByFarmerId(@PathVariable("id") Long farmerId);

    @DeleteMapping("/api/farmer/delete/{email}")
    void deleteFarmerByEmail(@PathVariable("email") String email);

}