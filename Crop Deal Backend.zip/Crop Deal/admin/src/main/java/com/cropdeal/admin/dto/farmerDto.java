package com.cropdeal.admin.dto;

import lombok.Data;

@Data
public class farmerDto {
    private Long farmerId;
    private String name;
    private String email;


}