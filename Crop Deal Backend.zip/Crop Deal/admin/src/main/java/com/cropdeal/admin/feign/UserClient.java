package com.cropdeal.admin.feign;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@FeignClient(name = "AUTHSERVICE")
public interface UserClient {

    @DeleteMapping("/api/user/delete/farmer/{email}")
    String DeleteFarmerEmail(@PathVariable("email") String farmerEmail);

    @DeleteMapping("/api/user/delete/dealer/{email}")
    String DeleteDealerEmail(@PathVariable("email") String dealerEmail);

    @GetMapping("/api/user/all")
    List<Object> Getalluser();

    @GetMapping("/api/user/{Id}")
    Optional<Object> getUserById(Long id);
}
