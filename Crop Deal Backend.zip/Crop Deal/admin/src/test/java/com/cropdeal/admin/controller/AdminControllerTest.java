package com.cropdeal.admin.controller;

import com.cropdeal.admin.dto.dealerDto;
import com.cropdeal.admin.dto.farmerDto;
import com.cropdeal.admin.service.AdminServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AdminControllerTest {

    @Mock
    private AdminServiceImpl adminServiceImp;

    @InjectMocks
    private AdminController adminController;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

   // Welcome Message for admin
    @Test
    void welcome_returnsGreeting() {
        assertEquals("Welcome to Admin Portal", adminController.welcome());
    }

    // Find All Farmers
    @Test
    void getAllFarmers_success() {
        List<farmerDto> farmers = List.of(new farmerDto(), new farmerDto());
        when(adminServiceImp.getAllFarmers()).thenReturn(farmers);

        ResponseEntity<List<farmerDto>> resp = adminController.getAllFarmers();

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(farmers,          resp.getBody());
        verify(adminServiceImp).getAllFarmers();
    }

    // Find All Farmers When Not Found
    @Test
    void getAllFarmers_notFound() {
        when(adminServiceImp.getAllFarmers()).thenThrow(new RuntimeException("no farmers"));

        ResponseEntity<List<farmerDto>> resp = adminController.getAllFarmers();

        assertEquals(HttpStatus.NOT_FOUND, resp.getStatusCode());
        assertNull(resp.getBody());
        verify(adminServiceImp).getAllFarmers();
    }

   // Delete Farmer By Email
    @Test
    void deleteFarmer_returnsServiceMessage() {
        String email = "farmer@ex.com";
        when(adminServiceImp.deleteByFarmerEmail(email))
                .thenReturn("Farmer deleted: " + email);

        ResponseEntity<String> resp = adminController.deleteFarmer(email);

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals("Farmer deleted: " + email, resp.getBody());
        verify(adminServiceImp).deleteByFarmerEmail(email);
    }

    // Get All Dealers
    @Test
    void getAllDealers_success() {
        List<dealerDto> dealers = List.of(new dealerDto());
        when(adminServiceImp.getAllDealers()).thenReturn(dealers);

        ResponseEntity<List<dealerDto>> resp = adminController.getAllDealers();

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(dealers,         resp.getBody());
        verify(adminServiceImp).getAllDealers();
    }


    // allusers  (GET)

    @Test
    void allusers_returnsMixedList() {
        Object users = List.of("user1", "user2");
        when(adminServiceImp.getalluser()).thenReturn((List<Object>) users);

        ResponseEntity<Object> resp = adminController.allusers();

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(users,           resp.getBody());
        verify(adminServiceImp).getalluser();
    }
}
