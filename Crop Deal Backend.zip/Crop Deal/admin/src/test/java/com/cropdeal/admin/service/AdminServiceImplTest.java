package com.cropdeal.admin.service;

import com.cropdeal.admin.Exception.ResourceNotFound;
import com.cropdeal.admin.dto.dealerDto;
import com.cropdeal.admin.dto.farmerDto;
import com.cropdeal.admin.feign.DealerServiceClient;
import com.cropdeal.admin.feign.FarmerServiceClient;
import com.cropdeal.admin.feign.UserClient;
import com.cropdeal.admin.repository.AdminRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AdminServiceImplTest {

    private AdminRepository adminRepository;
    private FarmerServiceClient farmerClient;
    private DealerServiceClient dealerClient;
    private UserClient  userClient;

    private AdminServiceImpl adminService;      // class under test

    @BeforeEach
    void init() {
        adminRepository = mock(AdminRepository.class);
        farmerClient = mock(FarmerServiceClient.class);
        dealerClient = mock(DealerServiceClient.class);
        userClient  = mock(UserClient.class);

        adminService = new AdminServiceImpl();
        // inject mocks manually (field injection style)
        adminService.adminRepository = adminRepository;
        adminService.farmerServiceClient = farmerClient;
        adminService.dealerServiceClient  = dealerClient;
        adminService.userClient  = userClient;
    }

    // Find All Farmers
    @Test
    void getAllFarmers_returnsList() {
        List<farmerDto> list = List.of(new farmerDto(), new farmerDto());
        when(farmerClient.getAllFarmers()).thenReturn(list);

        List<farmerDto> result = adminService.getAllFarmers();

        assertEquals(2, result.size());
        verify(farmerClient).getAllFarmers();
    }

    // Find All Farmers when there is no farmer in the database
    @Test
    void getAllFarmers_throwsWhenEmpty() {
        when(farmerClient.getAllFarmers()).thenReturn(Collections.emptyList());

        assertThrows(ResourceNotFound.class, adminService::getAllFarmers);
    }

    // Find All Dealers
    @Test
    void getAllDealers_returnsList() {
        List<dealerDto> list = List.of(new dealerDto(), new dealerDto(), new dealerDto());
        when(dealerClient.getAllDealers()).thenReturn(list);

        List<dealerDto> result = adminService.getAllDealers();

        assertEquals(3, result.size());
        verify(dealerClient).getAllDealers();
    }

    // Find All Dealers When there is no any dealer
    @Test
    void getAllDealers_throwsWhenEmpty() {
        when(dealerClient.getAllDealers()).thenReturn(null);   // or empty list

        assertThrows(ResourceNotFound.class, adminService::getAllDealers);
    }

    // Delete By Farmer Email
    @Test
    void deleteByFarmerEmail_invokesBothServices() {
        String email = "farmer@ex.com";

        // No need to stub void methods unless testing for exceptions
        adminService.deleteByFarmerEmail(email);

        verify(farmerClient).deleteFarmerByEmail(email);
        verify(userClient).DeleteFarmerEmail(email);
    }


    // Delete By Dealer Email
    @Test
    void deleteByDealerEmail_invokesBothServices() {
        String email = "dealer@ex.com";

        // No need for doNothing() on void methods
        String msg = adminService.deleteByDealerEmail(email);

        assertEquals("User deleted SuccessFully!!", msg);
        verify(dealerClient).deleteByEmail(email);
        verify(userClient).DeleteDealerEmail(email);
    }



}
