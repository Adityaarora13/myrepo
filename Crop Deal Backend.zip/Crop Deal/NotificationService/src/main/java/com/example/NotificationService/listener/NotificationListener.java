package com.example.NotificationService.listener;

import com.example.NotificationService.config.RabbitMQConfig;
import com.example.NotificationService.service.NotificationService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotificationListener {

    @Autowired
    private NotificationService notificationService;

//    @RabbitListener(...) → Ye annotation bolta hai:
//            "Is method ko RabbitMQ ke is queue se messages sunne ke liye laga do."
//
//    RabbitMQConfig.QUEUE → Matlab notification_queue se sunega.
//
//    String message → Jo bhi message aayega queue se, wo yahaan as a String aayega.

    @RabbitListener(queues = RabbitMQConfig.QUEUE)
    public void consumeMessage(String message) {  // <-- Changed from NotificationRequest to String
        System.out.println("Received HTML Message: " + message);

        // Now you have raw HTML here (if needed, you can parse or send as email)
        // notificationService.sendNotification(...);
    }
}
