package com.example.NotificationService.dto;

public class NotificationRequest {

    private String name;
    private String email;

    // Getters and Setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Optional: constructor
    public NotificationRequest(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Default constructor for deserialization
    public NotificationRequest() {
    }
}
