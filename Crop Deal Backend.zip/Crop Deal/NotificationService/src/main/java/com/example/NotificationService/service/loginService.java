package com.example.NotificationService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class loginService {

    private static final Logger logger = LoggerFactory.getLogger(loginService.class);

    //Spring ka built-in mail sending tool. Yeh hi email bhejne ka actual kaam karta hai.
    @Autowired
    private JavaMailSender mailSender;

    //    TemplateEngine → Thymeleaf ka engine jo HTML template ko dynamic content ke saath process karta hai.
    @Autowired
    private TemplateEngine templateEngine;

    // Inject the sender email from application.properties
    @Value("${spring.mail.username}")
    private String fromEmail;

    public void sendNotification(String toEmail) {
        logger.info("Preparing login notification email for: {}", toEmail);

        // Create Thymeleaf Context and add variables
        // Thymeleaf ke liye ek empty context bana diya (isme aap variables set kar sakte ho agar required ho).
        Context context = new Context();

        // login.html naam ka HTML template file uthaya, process kiya, aur
        // uska final HTML output bana liya.
        // Example: "Welcome back, user!"
        // Process the HTML template
        String htmlBody = templateEngine.process("login", context);
        logger.debug("Login email HTML content generated for: {}", toEmail);

        // Create and send the email
        // Ek complex email object banaya jisme subject, body, HTML, images
        // wagairah attach kar sakte hain.
        MimeMessage mimeMessage = mailSender.createMimeMessage();

        try {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(fromEmail);  // Sender email from application.properties
            helper.setTo(toEmail);
            helper.setSubject("Login notification");
            helper.setText(htmlBody, true); // true = HTML email

            mailSender.send(mimeMessage);

            logger.info("HTML Notification email sent successfully to {}", toEmail);
        } catch (MessagingException e) {
            logger.error("Failed to send login email to {}", toEmail, e);
            System.out.println("Failed to send email to " + toEmail);
        }
    }
}
