package com.example.NotificationService.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.converter.MessageConverter;


@Configuration
public class RabbitMQConfig {

    public static final String QUEUE = "notification_queue";
    public static final String EXCHANGE = "notification_exchange";
//    message ka path define karta hai
    public static final String ROUTING_KEY = "notification_routingKey";


//    Queue ek jagah hoti hai jahan messages temporarily store
//    hote hain jab tak koi consumer unhe le na le.
//    notification_queue naam se ek queue banegi.
    @Bean
    public Queue queue() {
        return new Queue(QUEUE);
    }

//    Exchange decide karta hai ki message kis queue me jaayega.
//
//    TopicExchange ka matlab: messages routing key ke pattern match
//    hone par appropriate queue me jaate hain.
    @Bean
    public TopicExchange exchange() {
        return new TopicExchange(EXCHANGE);
    }

//    Ye batata hai ki messages ko JSON ↔ Java Object me kaise convert karna hai.
//
//    MappingJackson2MessageConverter Spring ko allow karta hai RabbitMQ se aaye
//    JSON messages ko automatically Java objects me badalne ke liye (aur vice versa).
//
    @Bean
    public MessageConverter messageConverter() {
        return new MappingJackson2MessageConverter(); // Jackson for JSON -> Object conversion
    }

//    Ye binding batata hai: "Ye wali queue, is exchange ke saath, is routing key ke" +
//        " zariye jodi jaaye."
//
//    Jab koi message notification_routingKey ke saath exchange me bheja jaayega, to
//    wo notification_queue me chala jaayega.

    @Bean
    public Binding binding(Queue queue, TopicExchange exchange) {
        return BindingBuilder
                .bind(queue)
                .to(exchange)
                .with(ROUTING_KEY);
    }
}
