package com.example.NotificationService.controller;

import com.example.NotificationService.config.RabbitMQConfig;
import com.example.NotificationService.dto.NotificationRequest;
import com.example.NotificationService.dto.loginDto;
import com.example.NotificationService.service.NotificationService;
import com.example.NotificationService.service.loginService;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//NotificationService → Welcome email bhejne ke liye
//
//loginService → Login email bhejne ke liye
//
//AmqpTemplate → RabbitMQ me message bhejne ke liye
//
//TemplateEngine (Thymeleaf) → Email ka HTML content banane ke liye (jaise welcome.html, login.html)

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private static final Logger logger = LoggerFactory.getLogger(NotificationController.class);

    @Autowired
    private NotificationService service;

    @Autowired
    private loginService services;

    @Autowired
    private AmqpTemplate amqpTemplate;

    @Autowired
    private TemplateEngine templateEngine;  // <<== ADD this!

    @PostMapping("/welcome")
    public void sendWelcome(@RequestBody NotificationRequest message) {
        logger.info("Received welcome email request for: {}", message.getEmail());

        // Create context and process the template
        Context context = new Context();
        context.setVariable("userName", message.getName());

        String htmlBody = templateEngine.process("welcome", context); // this will now work
        logger.debug("Processed welcome template for user: {}", message.getName());

        // Send email
        service.sendNotification(
                message.getEmail(),
                message.getName()
        );
        logger.info("Welcome email sent to: {}", message.getEmail());

        // Send the HTML body to RabbitMQ
        amqpTemplate.convertAndSend(RabbitMQConfig.EXCHANGE, RabbitMQConfig.ROUTING_KEY, htmlBody);
        logger.info("Welcome email HTML sent to RabbitMQ for user: {}", message.getName());

        //        return "Message sent to "+ message.getName();
    }

    @PostMapping("/login")
    public void sendLogin(@RequestBody loginDto message) {
        logger.info("Received login email request for: {}", message.getEmail());

        // Create context and process the template
        Context context = new Context();

        String htmlBody = templateEngine.process("login", context); // this will now work
        logger.debug("Processed login template for user: {}", message.getEmail());

        // Send email
        services.sendNotification(
                message.getEmail()
        );
        logger.info("Login email sent to: {}", message.getEmail());

        // Send the HTML body to RabbitMQ
        amqpTemplate.convertAndSend(RabbitMQConfig.EXCHANGE, RabbitMQConfig.ROUTING_KEY, htmlBody);
        logger.info("Login email HTML sent to RabbitMQ for user: {}", message.getEmail());

        //        return "Message sent";
    }
}
