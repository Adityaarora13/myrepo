package com.example.NotificationService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class NotificationService {

    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TemplateEngine templateEngine;

    // Inject the sender email from application.properties
    @Value("${spring.mail.username}")
    private String fromEmail;

    public void sendNotification(String toEmail, String userName) {
        logger.info("Preparing welcome email for user: {} at {}", userName, toEmail);

        // Create Thymeleaf Context and add variables
        Context context = new Context();
        context.setVariable("userName", userName);

        // Process the HTML template
        String htmlBody = templateEngine.process("welcome", context);
        logger.debug("Generated HTML content for welcome email to: {}", toEmail);

        // Create and send the email
        MimeMessage mimeMessage = mailSender.createMimeMessage();

        try {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(fromEmail);  // Sender email from application.properties
            helper.setTo(toEmail);
            helper.setSubject("signup notification");
            helper.setText(htmlBody, true); // true = HTML email

            mailSender.send(mimeMessage);

            logger.info("Welcome email sent successfully to {}", toEmail);
            System.out.println("HTML Notification email sent successfully to " + toEmail);
        } catch (MessagingException e) {
            logger.error("Failed to send welcome email to {}", toEmail, e);
            System.out.println("Failed to send email to " + toEmail);
        }
    }
}
